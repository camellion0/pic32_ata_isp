#define REDUCED_SUPPORT
#define _formatted_write _small_write
#include "frmwri.c"
