#define NO_FLOATS
#define _formatted_write _medium_write
#include "frmwri.c"
