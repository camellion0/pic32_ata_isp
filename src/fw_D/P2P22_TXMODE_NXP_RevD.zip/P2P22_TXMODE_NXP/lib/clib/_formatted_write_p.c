#define FLOAT_SUPPORT
#include "frmwri_p.c"
