
#define COMPILE_ISLOWER
#define __8_BIT_ASCII_WANTED

#include "isxxx.c"

