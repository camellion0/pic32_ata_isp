
#define COMPILE_ISXDIGIT
#define __8_BIT_ASCII_WANTED

#include "isxxx.c"

