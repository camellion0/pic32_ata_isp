#define NO_FLOATS
#define _formatted_write_P _medium_write_P
#include "frmwri_p.c"
