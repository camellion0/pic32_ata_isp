#define FLOAT_SUPPORT
#include "frmrd_p.c"
