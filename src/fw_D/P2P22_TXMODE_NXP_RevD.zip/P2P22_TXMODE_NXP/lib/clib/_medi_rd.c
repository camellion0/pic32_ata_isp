#define NO_FLOATS
#define _formatted_read _medium_read
#include "frmrd.c"
