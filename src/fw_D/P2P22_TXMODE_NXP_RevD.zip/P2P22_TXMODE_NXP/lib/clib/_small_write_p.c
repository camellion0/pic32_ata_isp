#define REDUCED_SUPPORT
#define _formatted_write_P _small_write_P
#include "frmwri_p.c"
