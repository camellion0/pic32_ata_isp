#define FLOAT_SUPPORT
#include "frmwri.c"
