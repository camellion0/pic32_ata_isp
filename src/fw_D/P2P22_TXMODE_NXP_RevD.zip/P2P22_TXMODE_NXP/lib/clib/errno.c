/*                      - ERRNO.C -

   The definition place of the ANSI error status variable.

   $Revision: 328482 $

   Copyright 1986 - 1999 IAR Systems. All rights reserved.
*/

int errno;
