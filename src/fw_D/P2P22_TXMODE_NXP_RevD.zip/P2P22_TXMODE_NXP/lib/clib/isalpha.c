
#define COMPILE_ISALPHA
#define __8_BIT_ASCII_WANTED

#include "isxxx.c"

