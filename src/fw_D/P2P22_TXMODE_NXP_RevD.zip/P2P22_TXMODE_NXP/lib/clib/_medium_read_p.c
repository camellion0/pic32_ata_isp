#define NO_FLOATS
#define _formatted_read_P _medium_read_P
#include "frmrd_p.c"
