/* *C**************************************************************************
  Use of this software is subject to Atmel's Software License Agreement.
-------------------------------------------------------------------------------
  $URL: http://svnservulm.corp.atmel.com/svn/CDB/Apps/SW_Lib/Car_Access/CARS_GEN2/ATAB5702A/Branches/P2_Gen2_Merge/appl/appFlash/src/FlashApplRF.c $
  $LastChangedRevision: 350433 $
  $LastChangedDate: 2015-11-09 16:53:40 -0700 (Mon, 09 Nov 2015) $
  $LastChangedBy: grueter $
-------------------------------------------------------------------------------
  Project:      ATA5700
  Target MCU:   ATA5700
  Compiler:     IAR C/C++ Compiler for AVR 5.51.0
-------------------------------------------------------------------------------

*******************************************************************************
* Copyright 2011, Atmel Automotive GmbH                                       *
*                                                                             *
* This software is owned by the Atmel Automotive GmbH                         *
* and is protected by and subject to worldwide patent protection.             *
* Atmel hereby grants to licensee a personal,                                 *
* non-exclusive, non-transferable license to copy, use, modify, create        *
* derivative works of, and compile the Atmel Source Code and derivative       *
* works for the sole purpose of creating custom software in support of        *
* licensee product to be used only in conjunction with a Atmel integrated     *
* circuit as specified in the applicable agreement. Any reproduction,         *
* modification, translation, compilation, or representation of this           *
* software except as specified above is prohibited without the express        *
* written permission of Atmel.                                                *
*                                                                             *
* Disclaimer: ATMEL MAKES NO WARRANTY OF ANY KIND,EXPRESS OR IMPLIED,         *
* WITH REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED    *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.         *
* Atmel reserves the right to make changes without further notice to the      *
* materials described herein. Atmel does not assume any liability arising     *
* out of the application or use of any product or circuit described herein.   *
* Atmel does not authorize its products for use as critical components in     *
* life-support systems where a malfunction or failure may reasonably be       *
* expected to result in significant injury to the user. The inclusion of      *
* Atmel products in a life-support systems application implies that the       *
* manufacturer assumes all risk of such use and in doing so indemnifies       *
* Atmel against all charges.                                                  *
*                                                                             *
* Use may be limited by and subject to the applicable Atmel software          *
* license agreement.                                                          *
******************************************************************************/

/** \file FlashApplRF.c
    this file contains an ATA5700 Flash application software
*/

/*===========================================================================*/
/*  INCLUDES                                                                 */
/*===========================================================================*/
#include "../../../firmware/init/src/init.h"
#include "../../../firmware/rftx/src/rftx.h"
#include "../../../firmware/lfrx/src/lfrx.h"
#include "../../../firmware/spi/src/ata5700_command_set.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"
#include "../../../firmware/init/src/init_flash.h"
#include "../../../firmware/system/src/system_flash.h"

#include "../../../firmware/timer1/src/timer1.h"
#include "../../../firmware/globals/src/globals.h"
#include "../../../firmware/timer5/src/timer5_flash.h"

#include "../../../firmware/lfrx/src/lfrx_flash.h"
#include "../../../firmware/tp/src/tp_flash.h"

#include "../../../firmware/extif/src/extif_flash.h"

#include "../../../firmware/lfrssi/src/lfrssi.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"

#include "../../../firmware/calib/src/calib.h"
#include "../../../firmware/aes/src/aes.h"

//--------

#include "../src/FlashApplPEPS.h"
#include "../src/FlashApplRF.h"
#include "../src/FlashApplLF.h" 
#include "../src/micro.h"
#include "../src/FlashApplVars.h"
#include "rfrcc_flash.h"
#include "FlashApplVars.h"
#include "FlashApplMsg.h"

/*===========================================================================*/
/*  DEFINES                                                                  */
/*===========================================================================*/
#define TX_PAYLOADDATALENGTH    32
#define RF_FRAME_LENGTH(NB_BYTES) (1000.0/CFG_RF1_BITRATE*8.0*(NB_BYTES+0.5))
/*===========================================================================*/
/*  Modul Globals                                                             */
/*===========================================================================*/
extern sFlashApplVars gFlashApplVars;
extern RFMSG_FRAME_TS g_MsgRXbuffer;
extern RFMSG_FRAME_TS g_MsgTXbuffer;
extern sFlashApplState gFlashApplState;
extern sFlashApplVars gFlashApplVars;
extern tTimer5Status gTimer5Status;
//RF message length (with only one byte of preamble)
static CONST uint8_t caub_frame_auth_delay[8] =
{
  0,
  (uint8_t)((RF_FRAME_LENGTH(PEPS_SIZE_TX_MSG_AUTH) + INTERFRAME)*1 + 0.5),
  (uint8_t)((RF_FRAME_LENGTH(PEPS_SIZE_TX_MSG_AUTH) + INTERFRAME)*2 + 0.5),
  (uint8_t)((RF_FRAME_LENGTH(PEPS_SIZE_TX_MSG_AUTH) + INTERFRAME)*3 + 0.5),
  (uint8_t)((RF_FRAME_LENGTH(PEPS_SIZE_TX_MSG_AUTH) + INTERFRAME)*4 + 0.5),
  (uint8_t)((RF_FRAME_LENGTH(PEPS_SIZE_TX_MSG_AUTH) + INTERFRAME)*5 + 0.5),
  (uint8_t)((RF_FRAME_LENGTH(PEPS_SIZE_TX_MSG_AUTH) + INTERFRAME)*6 + 0.5),
  (uint8_t)((RF_FRAME_LENGTH(PEPS_SIZE_TX_MSG_AUTH) + INTERFRAME)*7 + 0.5),
};
static CONST uint8_t caub_tx_length[16] =
{
  PEPS_SIZE_TX_MSG_ID,
  PEPS_SIZE_TX_MSG_PARAM, //PEPS_CID_RD_PARAM  1
  PEPS_SIZE_TX_MSG_PARAM, //PEPS_CID_WR_PARAM  2
  0,
  PEPS_SIZE_TX_MSG_2WAY, //PEPS_CID_2WAY 4
  PEPS_SIZE_TX_MSG_AUTH, //PEPS_CID_UNI_AUTH 5
  PEPS_SIZE_TX_MSG_AUTH, //PEPS_CID_BI_AUTH  6
  PEPS_SIZE_TX_MSG_AUTH, //PEPS_CID_UNI_AUTH_SINGLE 7
  PEPS_SIZE_TX_MSG_AUTH, //PEPS_CID_UNI_AUTH_SINGLE 8
  0,
  PEPS_SIZE_TX_MSG_LF_TST, //PEPS_CID_LF_TST  10
  PEPS_SIZE_TX_MSG_LF_PARAM, //PEPS_CID_LF_PARAM 11
  0,
  0,
  PEPS_SIZE_TX_MSG_SWID, //PEPS_CID_SWID 14
  PEPS_SIZE_TX_MSG_MODE  //PEPS_CID_MODE 15
};
extern uint8_t rub_cid;
/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/
//static VOIDFUNC ATA_rfTx_lFRssi_flash_C(void);
void ATA_rfTx_PEPSmsg_flash_C(void);
void ATA_rfTx_PEPSframe_flash_C(void);
/*----------------------------------------------------------------------------- */
/**\brief  TODO - code here

 */
/*----------------------------------------------------------------------------- */
void ATA_rfTx_lFRssi_flash_C(void)
{
  uint8_t index;  
  uint8_t checksum;
          PORTD |= (1<<4);  // Set PD4 high (LED2)
          for (index = 0; index < 14; index++)
          {
         
            gFlashApplVars.RfTxbuffer[index] = 0xff;
          }
       
           gFlashApplVars.RfTxbuffer [14] = 0xFEU; 
           gFlashApplVars.RfTxbuffer [15] = 0x39U; 
      
         
          
          for (index = 0; index < 23; index++)
          {
           
            checksum = gFlashApplVars.RfTxbuffer[index];
          }
         
          gFlashApplVars.RfTxbuffer[23]= ~checksum+1;
         ATA_rfTxInit_C();
       
         ATA_rfTxFillDFifo_C(0x19U,  gFlashApplVars.RfTxbuffer);
          // start rfTx with eeprom service g_sEepRfTxServiceConfig1
  
         //  uint8_t *pService = ATA_5700convertTrxConf2rfTxService_flash_C();
         //  ATA_rfTxStartTx_C(0x48, (uint8_t *) pService);          
          ATA_rfTxStartTx_C(0x48, (uint8_t *) (uint8_t *) &g_sCustomerEEPromSection.eepRfTxSer0Ptr_l);
          //Service 0 location in EEPROM is to never be initialized !!!
       
         // ATA_rfTxStartTx_C(0x48, (uint8_t *) 0x06D0);//0x06do from where?
          
          
          do {
            ATA_rfTxProcessing_C();
             }while (g_sRfTx.bStatus & BM_RFTXCONFIG_BSTATUS_ACTIVE);
          for (uint8_t cnt=0;cnt<255;cnt++);
          ATA_rfTxStop_C();
          PORTD &= 0xef;     // Set PD4 low         
}

void ATA_rfTx_PEPSmsg_flash_C(void)
{
  //Send message in common and FOB index time slots
  uint8_t Fob_tempo;//Delay timing position (slot)
  uint8_t Fob_slots;//TX slots 
  // compute interframe for anti-collicion process
  Fob_tempo = 0;
  Fob_slots = SLOT_COMMON;
 
  if ((rub_cid==PEPS_CID_UNI_AUTH) || (rub_cid==PEPS_CID_BI_AUTH))
  {
  Fob_slots = SLOT_COMMON|SLOT_SINGLES;//1 | 2
    // common slot + wait xxx ms before 2nd frame
    Fob_tempo = MSG_TX_DATA.peps.fidx - ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx;//TX Data FOB Index - RX message FOB Index
    if (Fob_tempo & 0x80)  
    {
      // Fob index lower than index requested
      Fob_tempo += PEPS_NB_FOB_MAX; //Add 4 to it?
    }
    // interframe is 3ms, and frame length is around 8ms
    // =((1000/CFG_RF1_BITRATE*8*(PEPS_SIZE_TX_MSG_AUTH+CFG_PEPS_PREAMBLE_LENGTH-1+0.5)+0.5)
    Fob_tempo = (uint8_t)INTERFRAME + caub_frame_auth_delay[Fob_tempo];    
  }
  // send first frame
  if (Fob_slots&SLOT_COMMON)
  {
   // gFlashApplVars.RKEcommand=0;
    ATA_rfTx_PEPSframe_flash_C();
  }  
  // send second frame
  if (Fob_slots&SLOT_SINGLES)
  {
    if (Fob_tempo)
    {
     ATA_PEPStimerStart(Fob_tempo-1);
     gFlashApplState.State |= BM_PEPSRFTIMERACTIVE;     
    }    
  
  }  
}

void ATA_rfTx_PEPSrftimingprocess_flash_C(void)
{ 
      T5IMR = 0x00; 
      _WDR;  
      ATA_PEPStimerProcess();
      gFlashApplState.State &= ~(BM_PEPSRFTIMERACTIVE); 
      gTimer5Status &= ~(BM_TIMER5COMPARETRUE);
    // send 2nd frame
      ATA_rfTx_PEPSframe_flash_C();
}

void ATA_rfTx_PEPSframe_flash_C(void)
{
  // if ((PORTD & 0x04)==0x04) PORTD &= ~(1<<PORTD2);
  // else PORTD |= (1<<PORTD2); 
   if ((PORTC & 0x02)==0x02) PORTC &= ~(1<<PORTC1);
   else PORTC |= (1<<PORTC1); 
  g_MsgTXbuffer.ub_size = caub_tx_length[rub_cid]; 
   ATA_rfTxInit_C();   
   ATA_rfTxFillDFifo_C(g_MsgTXbuffer.ub_size, g_MsgTXbuffer.aub_data);//gFlashApplVars.RfTxbuffer);
   ATA_rfTxStartTx_C(0x48, (uint8_t *) 0x06D0);
   do {
        ATA_rfTxProcessing_C();
       }while (g_sRfTx.bStatus & BM_RFTXCONFIG_BSTATUS_ACTIVE);
   ATA_rfTxStop_C();
   SUPCR &= ~BM_AVEN;
  //  if ((PORTD & 0x04)==0x04) PORTD &= ~(1<<PORTD2);
 // else PORTD |= (1<<PORTD2);
     if ((PORTC & 0x02)==0x02) PORTC &= ~(1<<PORTC1);
   else PORTC |= (1<<PORTC1); 
}