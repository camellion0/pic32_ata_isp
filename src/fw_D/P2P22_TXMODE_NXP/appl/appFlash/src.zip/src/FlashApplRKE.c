/* *C**************************************************************************
  Use of this software is subject to Atmel's Software License Agreement.
-------------------------------------------------------------------------------
  $URL: http://svnservulm.corp.atmel.com/svn/CDB/Apps/SW_Lib/Car_Access/CARS_GEN2/ATAB5702A/Branches/P2_Gen2_Merge/appl/appFlash/src/FlashApplRKE.c $
  $LastChangedRevision: 356277 $
  $LastChangedDate: 2015-12-08 10:39:17 -0700 (Tue, 08 Dec 2015) $
  $LastChangedBy: mhahnen $
-------------------------------------------------------------------------------
  Project:      ATA5700
  Target MCU:   ATA5700
  Compiler:     IAR C/C++ Compiler for AVR 5.51.0
-------------------------------------------------------------------------------

*******************************************************************************
* Copyright 2011, Atmel Automotive GmbH                                       *
*                                                                             *
* This software is owned by the Atmel Automotive GmbH                         *
* and is protected by and subject to worldwide patent protection.             *
* Atmel hereby grants to licensee a personal,                                 *
* non-exclusive, non-transferable license to copy, use, modify, create        *
* derivative works of, and compile the Atmel Source Code and derivative       *
* works for the sole purpose of creating custom software in support of        *
* licensee product to be used only in conjunction with a Atmel integrated     *
* circuit as specified in the applicable agreement. Any reproduction,         *
* modification, translation, compilation, or representation of this           *
* software except as specified above is prohibited without the express        *
* written permission of Atmel.                                                *
*                                                                             *
* Disclaimer: ATMEL MAKES NO WARRANTY OF ANY KIND,EXPRESS OR IMPLIED,         *
* WITH REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED    *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.         *
* Atmel reserves the right to make changes without further notice to the      *
* materials described herein. Atmel does not assume any liability arising     *
* out of the application or use of any product or circuit described herein.   *
* Atmel does not authorize its products for use as critical components in     *
* life-support systems where a malfunction or failure may reasonably be       *
* expected to result in significant injury to the user. The inclusion of      *
* Atmel products in a life-support systems application implies that the       *
* manufacturer assumes all risk of such use and in doing so indemnifies       *
* Atmel against all charges.                                                  *
*                                                                             *
* Use may be limited by and subject to the applicable Atmel software          *
* license agreement.                                                          *
******************************************************************************/

/** \file FlashApplRKE.c
    this file contains an ATA5700 Flash application software
*/

/*===========================================================================*/
/*  INCLUDES                                                                 */
/*===========================================================================*/
#include "../../../firmware/init/src/init.h"
#include "../../../firmware/rftx/src/rftx.h"
#include "../../../firmware/lfrx/src/lfrx.h"
//#include "../../../firmware/rfrcc/src/rfrcc.h"
#include "../../../firmware/spi/src/ata5700_command_set.h"

#include "../../../firmware/init/src/init_flash.h"
#include "../../../firmware/system/src/system_flash.h"
#include "../../../firmware/rftx/src/rftx.h"
#include "../../../firmware/timer1/src/timer1.h"
#include "../../../firmware/globals/src/globals.h"

#include "../../../firmware/lfrx/src/lfrx_flash.h"
#include "../../../firmware/tp/src/tp_flash.h"

#include "../../../firmware/extif/src/extif_flash.h"

#include "../../../firmware/lfrssi/src/lfrssi.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"

#include "../../../firmware/calib/src/calib.h"
#include "../../../firmware/aes/src/aes.h"


#include "../src/FlashApplPEPS.h"
#include "../src/FlashApplLF.h" 
#include "../src/micro.h"

#include "../src/FlashApplVars.h"


#include "rfrcc_flash.h"
#include "FlashApplVars.h"
#include "FlashApplMsg.h"

/*===========================================================================*/
/*  DEFINES                                                                  */
/*===========================================================================*/
#define MSG_RX_DATA (g_MsgRXbuffer.aub_data)
/*===========================================================================*/
/*  Modul Globals                                                             */
/*===========================================================================*/


eAesSecretKeySelection bAesSecretKeySelection = AES_USE_SECRET_KEY_A;
uint8_t bUserCmd=0xa5;
extern  uint16_t g_EepRFRcc_flash;
extern uint8_t guiButton;
extern sFlashApplState gFlashApplState;
extern sFlashApplVars gFlashApplVars;
extern uint16_t wEepRfrccAddress;

extern sCustomerEEPromSection g_sCustomerEEPromSection;
extern sEepFlashApp_AESKey g_sEepFlashApp_AESKey;

extern RFMSG_FRAME_TS g_MsgRXbuffer;
extern RFMSG_FRAME_TS g_MsgTXbuffer;

extern uint8_t rub_cid;
extern uint8_t rub_wuip;
extern uint8_t rub_fob_idx;
extern uint8_t rul_fob_id;
extern uint8_t rub_rf_chan;
extern uint8_t gVbat_Status;
extern sEepFlashApp_RKEPEPS g_sEepFlashApp_RKEPEPS;
   
/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/
/** \brief <b>ATA_Flash_RKEsend(void)</b>
    Shall configure the 3D LF receiver into LF listen mode and activate
      the ID0 wake-up interrupt

    \param[in]  bLfBdrate       selects the LF baud rate
                bSense          selects the LF RX sensitivity
                pLf_Id          pointer to the LF wake-up ID
                bLf_IdLength    number of LF ID bits

    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
void ATA_Flash_RKEbuttonProcessOut (void)
{
  MSG_TX_DATA.rke.preamble1 = 0xfe;//Start bit in preamble byte 16
  g_sRfrccComponentData.bFlags = RFRCC_FLAGS_RESET;
 // ATA_rfrccGenRollCntMsg_C((uint16_t)&wEepRfrccAddress, 0x00, gFlashApplVars.RKEcommand, 0x00); 
  ATA_rfrccGenRollCntMsg_C((uint16_t)&eul_rolling_code, 0x00, gFlashApplVars.RKEcommand, 0x00);  

  //for (uint8_t index = 0; index < (RKE_RFMESSAGEPREAMPLELENGTH-1); index++)Something changed 21Oct2015?
  for (uint8_t index = 0; index < (RKE_RFMESSAGEPREAMPLELENGTH); index++)
        {
          MSG_TX_DATA.rke.preamble0[index]=0xff;
        }
   for (uint8_t index = 0; index < 13; index++)
        {
          g_MsgTXbuffer.aub_data[(index+1)+RKE_RFMESSAGEPREAMPLELENGTH] = g_sRfrccComponentData.bRollCodeMsgBuffer[index];
        }   
        g_MsgTXbuffer.aub_data[(14)+RKE_RFMESSAGEPREAMPLELENGTH]=0x00;//Force the last bayte to 0x00 
        ATA_rfTxInit_C();      
        ATA_rfTxFillDFifo_C((RKE_RFMESSAGELENGTH+2), g_MsgTXbuffer.aub_data);//Added one, CAB + Omega2 missing last byte    
        ATA_rfTxStartTx_C( (BM_RFTXCONFIG_BCONFIG_SVC_LOCATION|BM_RFTXCONFIG_BCONFIG_VCO_TUNING), (uint8_t *) 0x06D0);//Need variable name for service 1 location in EEPROM
        do {
          ATA_rfTxProcessing_C();
          
        }while (g_sRfTx.bStatus & BM_RFTXCONFIG_BSTATUS_ACTIVE);
        ATA_rfTxStop_C();      
        SUPCR &= ~BM_AVEN;
        bit_clear(LED1);
        gFlashApplState.Buttons &= ~BM_NEWCMNDVALID;  //Clear new command available flag
        Intr_Enable(SW1_INTR);    //Enable SW1,2,3 interrupts 
        Intr_Enable(SW2_INTR);
        Intr_Enable(SW3_INTR);       
        T0CR = 0;
        if (MSG_TX_DATA.rke.commandCode[0]==0x02)//If middle button transmit PEPS RF message TEST MODE ONLY DELETE DELETE!!!!! 
        {
          //load up the data message to be tested
          for (uint8_t index = 0; index < (RKE_RFMESSAGEPREAMPLELENGTH); index++)
          {
          MSG_TX_DATA.rke.preamble0[index]=0xff;
          }     
          MSG_TX_DATA.peps.preamble1 = 0xfe;
         
          //Increment through the FOB index requested to test timing
          
          static uint8_t ReqFobIndex;
         
          ReqFobIndex++;
          if (ReqFobIndex>4)ReqFobIndex=1;
          
         
          ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx=ReqFobIndex;//Set priority FOB index
          
     
          MSG_TX_DATA.peps.fidx=0x03;//Set internal FOB index
          
          ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->cid=0x05;
          MSG_TX_DATA.peps.cid=0x07;
          MSG_TX_DATA.peps.bat=0x00;   
          for (uint8_t index = 0; index < 4; index++)
          {
          MSG_TX_DATA.peps.data_authent.mac[index]=index+6;
          }
          MSG_TX_DATA.peps.data_authent.rssil=0xa5; 
          rub_cid=0x05; //Unilateral authentication command ID
          
             
          
          ATA_rfTx_PEPSmsg_flash_C();
        }
  
}
