/* *C**************************************************************************
  Use of this software is subject to Atmel's Software License Agreement.
-------------------------------------------------------------------------------
  $URL: http://svnservulm.corp.atmel.com/svn/CDB/Apps/SW_Lib/Car_Access/CARS_GEN2/ATAB5702A/Branches/P2_Gen2_Merge/appl/appFlash/src/FlashAppl.c $
  $LastChangedRevision: 354570 $
  $LastChangedDate: 2015-11-30 08:55:29 -0700 (Mon, 30 Nov 2015) $
  $LastChangedBy: mhahnen $
-------------------------------------------------------------------------------
  Project:      ATA5700
  Target MCU:   ATA5700
  Compiler:     IAR C/C++ Compiler for AVR 5.51.0
-------------------------------------------------------------------------------

*******************************************************************************
* Copyright 2011, Atmel Automotive GmbH                                       *
*                                                                             *
* This software is owned by the Atmel Automotive GmbH                         *
* and is protected by and subject to worldwide patent protection.             *
* Atmel hereby grants to licensee a personal,                                 *
* non-exclusive, non-transferable license to copy, use, modify, create        *
* derivative works of, and compile the Atmel Source Code and derivative       *
* works for the sole purpose of creating custom software in support of        *
* licensee product to be used only in conjunction with a Atmel integrated     *
* circuit as specified in the applicable agreement. Any reproduction,         *
* modification, translation, compilation, or representation of this           *
* software except as specified above is prohibited without the express        *
* written permission of Atmel.                                                *
*                                                                             *
* Disclaimer: ATMEL MAKES NO WARRANTY OF ANY KIND,EXPRESS OR IMPLIED,         *
* WITH REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED    *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.         *
* Atmel reserves the right to make changes without further notice to the      *
* materials described herein. Atmel does not assume any liability arising     *
* out of the application or use of any product or circuit described herein.   *
* Atmel does not authorize its products for use as critical components in     *
* life-support systems where a malfunction or failure may reasonably be       *
* expected to result in significant injury to the user. The inclusion of      *
* Atmel products in a life-support systems application implies that the       *
* manufacturer assumes all risk of such use and in doing so indemnifies       *
* Atmel against all charges.                                                  *
*                                                                             *
* Use may be limited by and subject to the applicable Atmel software          *
* license agreement.                                                          *
******************************************************************************/

/** \file FlashAppl.c
    this file contains an ATA5700 Flash application software
*/

/*===========================================================================*/
/*  INCLUDES                                                                 */
/*===========================================================================*/
#include "../../../firmware/init/src/init.h"
#include "../../../firmware/rftx/src/rftx.h"
#include "../../../firmware/lfrx/src/lfrx.h"
#include "../../../firmware/spi/src/ata5700_command_set_flash.h"

#include "../../../firmware/init/src/init_flash.h"
#include "../../../firmware/system/src/system_flash.h"

#include "../../../firmware/timer1/src/timer1.h"
#include "../../../firmware/timer5/src/timer5_flash.h"
#include "../../../firmware/globals/src/globals.h"

#include "../../../firmware/lfrx/src/lfrx_flash.h"
#include "../../../firmware/tp/src/tp_flash.h"

#include "../../../firmware/extif/src/extif_flash.h"

#include "../../../firmware/lfrssi/src/lfrssi.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"

#include "../../../firmware/calib/src/calib.h"
#include "../../../firmware/aes/src/aes.h"

#include "../src/micro.h"
#include "rfrcc_flash.h"
#include "FlashApplVars.h"

#include "../src/FlashApplPEPS.h"
#include "FlashApplMSG.h"



#include "../src/FlashApplLF.h" 

/*===========================================================================*/
/*  DEFINES                                                                  */
/*===========================================================================*/
#define FLASH_MAJOR_VERSION     0x02U
#define FLASH_MINOR_VERSION     0x05U
#define FLASH_CUSTOMER_VERSION  0x00U


#define TX_PREAMBLEDATALENGTH   5
#define TX_PAYLOADDATALENGTH    32


/*===========================================================================*/
/*  Modul Globals                                                             */
/*===========================================================================*/
#pragma location = ".versions"
__root __flash static uint16_t flashVersion = (uint16_t)(((uint16_t)FLASH_MINOR_VERSION<<8U) | FLASH_MAJOR_VERSION);

#pragma location = ".versions"
__root __flash static uint8_t  customerVersion = FLASH_CUSTOMER_VERSION;

/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/


extern VOIDFUNC ATA_lfRxEnableWakeup_flash_C(uint8_t bLfBdrate,uint8_t bSense);
extern VOIDFUNC ATA_CheckLfData_flash_C(void);
extern VOIDFUNC Init_LfRssi_flash_C(void); 
extern VOIDFUNC gpio_init(void);
extern VOIDFUNC app_peps_handler(uint8_t lub_channel);

extern char ID0_Wake=0x00;
extern char ID1_Wake=0x00;
extern char LF_DecErrFlag=0x00; 
extern uint8_t gLfMessageReceived;

extern tTimer5Status gTimer5Status;
extern tPCINTStatus gPCINTStatus;

extern sCustomerEEPromSection g_sCustomerEEPromSection;
extern sEepFlashApp_AESKey g_sEepFlashApp_AESKey;
extern uint8_t g_EepFlashApp_FOBindx;
extern uint8_t g_EepFlashApp_USRID[4];

sFlashApplState gFlashApplState;
sFlashApplVars gFlashApplVars;

/*----------------------------------------------------------------------------- */
/**\brief  <b>main routine</b>
            for ATA5700 Flash application software to support the Primus2P
            test mode for the Tx library.

    The main function checks for a valid system wake up, initializes the system
    and enters the main loop which is responsible for command decoding, system
    control and sleep mode control.

 */
/*----------------------------------------------------------------------------- */
int16_t main(void)
{

  
  /* Use INTVEC at Flash start */
  MCUCR = BM_IVSEL | BM_IVL0;
  MCUCR |= (1<<ENPS);   // Enable Port Settings
 
    ATA_initAvrRegister_flash_C();

    /* Init global system events before performing */
   // ATA_5700InitCommandSet_flash_C();

    /* Store reset events and clear register. */
    g_sAta5700_flash.events_reset = MCUSR;
    MCUSR = 0x00U;

    /* Disable Watchdog during initialization. */
    ATA_globalsWdtDisable_C();
    ATA_globalsInitDebug_C();

    /* Perform Application initialization */
    if (ATA_initAta5700_flash_C() == FAIL){
        ATA_systemErrorLoop_flash_C();
    }


 /* Initialization of LF calibration data, only if LFVCC was off before. */
    if (1) //( (LFCPR & BM_LFCALRY) == 0x00U )
    {
    /* Initialization of LF calibration data */
        ATA_lfRxInit_C();

        /* System Verification Requirement, referenced as BUG "Primus2P-2165" */
        LFCPR = BM_LFCPCE;
        LFCPR = BM_LFCALRY;

        /* Primus2P-1827 and Primus2P-1670:
           This is a Flash Validation requirement to set T0 to the given value. */
        T0CR  = 0x12U;
        T0IFR = 0x01U;
        
        // Initialize LFREC, Power Mode
       ATA_lfRxEnableWakeup_flash_C(LFRX_BDR_3_90,LFRX_H_SENSE);
    }
    else
    {
        /* Enable clock for LF Receiver to be able to update its registers. */
        ATA_POWERON_C(PRR1, PRLFR);

        /* Set LF Calibration available indication */
        g_sAta5700_flash.events_reset |= BM_ATA5700_EVENTS_RESET_LF_CALRY;
    }
 
    /* Initialization of LF and TP module */
    ATA_lfRxInit_flash_C();

     ATA_tpRxTxInit_flash_C();
     
    /* Initialization of RFTX module */
    ATA_rfTxInit_C();
    
    Init_LfRssi_flash_C();

    ATA_lfRssiInit_C();
    
    /* Initialize calibration component */
    ATA_calibInit_C();

    /* initialization of AES module */
    ATA_aesInit_C();
    
    gpio_init();

    /* Application Board IO init */
   
    bit_clear(LED1);          //LED off        
    bit_set(LED1_DDR);        //LED port as output
    bit_clear(LED2);    
    bit_set(LED2_DDR);
    
    bit_clear(SW1_DDR);       // Push button as input
    bit_set(SW1);             // set pull-up 
    bit_clear(SW2_DDR);     
    bit_set(SW2); 
    bit_clear(SW3_DDR);     
    bit_set(SW3); 
    
    Intr_Enable(SW1_INTR);    //Enable SW1,2,3 interrupts 
    Intr_Enable(SW2_INTR);
    Intr_Enable(SW3_INTR);
    PCICR |= (1<<PCIE1);      //enable pin change int on PCINT[15:8]
    SPCR &= ~((1<<SPIE) | (1<<SPE)); // Disable SPI port
    SPSR &= ~((1<<SPIF) | (1<<TXIF) | (1<<RXIF));
    
    DDRB = 0;           // all pins on PB are inputs
    PORTB = 7;          // set pull-up on all push buttons 
    
    DDRC |= (1<<PORTC2);
    PORTC &= ~(1<<PORTC2);
    
    gFlashApplState.Buttons = 0x00U;//Clear button state
    
  /* ------- Move to IOinit.c someday--------------------------------------*/
    /*
    
   static uint8_t SecretKeyInit[16] = {0xff,0xee,0xdd,0xcc,0xbb,0xaa,0x99,0x88,0x77,0x66,0x5a,0x44,0x33,0x22,0x11,0x00};//Init secret key values
 //  static uint8_t UserIDInit[4] = {0x0b,0x0a,0x0b,0x0e};//Init secret key values
   static uint8_t FOBindxInit = 0x03;
   uint8_t fubarkey[EEP_SECRET_KEY_LENGTH]={0};//Array for EEPROM write validation - 16
   
   uint8_t keyaddress[2]={0x00};
   uint8_t keyaddressvalidate[2]={0x00};
 
   uint16_t fubarfubar = (uint16_t)&eaub_aes_key_fob;
   keyaddress[0] = (uint8_t)(fubarfubar & 0xff);
   keyaddress[1] = (uint8_t)(fubarfubar>>8);
   
   static uint8_t RXmsgInit[16]= {10,1,12,3,4,5,16,7,8,19,0x0a,0x0b,0x0c,0x0d,0x0e0,0x0f};//Init   
  
   for (uint8_t fubarcnt=0;fubarcnt<16;fubarcnt++)
   g_MsgRXbuffer.aub_data[fubarcnt] = RXmsgInit[fubarcnt];  
   
   ATA_eepWriteBytes_C(&SecretKeyInit[0],  (uint16_t)&eaub_aes_key_fob   , EEP_SECRET_KEY_LENGTH); // Load secret key 0 to EEPROM   
   ATA_eepReadBytes_C(&fubarkey[0], (uint16_t)&eaub_aes_key_fob   , EEP_SECRET_KEY_LENGTH); //REad back what we just wrote to validate
 
   ATA_eepWriteBytes_C(&keyaddress[0], ((uint16_t)&g_sCustomerEEPromSection.eepSecKeyAddrA), 0x02U); // Write secret key address to EEPROM 
   ATA_eepReadBytes_C(&keyaddressvalidate[0], (uint16_t)&g_sCustomerEEPromSection.eepSecKeyAddrA   , 0x02U); //REad back what we just wrote to validate
  
  // ATA_eepWriteBytes_C(&UserIDInit[0],  (uint16_t)&g_EepFlashApp_USRID   , 0x04); // Load USER ID  
   ATA_eepWriteBytes_C(&g_EepFlashApp_USRID[0],  (uint16_t)&g_EepFlashApp_USRID   , 0x04); // Load USER ID 


   ATA_eepWriteBytes_C(&FOBindxInit,  (uint16_t)&g_EepFlashApp_FOBindx   , 0x01); // Load FOB Index 
   */   
   char volatile count;
   
   /* Enable global interrupts */
    _SEI;
    
    ATA_eepReadBytes_C(gFlashApplVars.RfTxbuffer, 0xE8, 0x08);
    
       for(;;)
    {
      _WDR;
       ATA_globalsClkSwitchFrc_C();
      /* toggle GPIOR0.2 to indicate main loop frequency */
      GPIOR0 ^= BIT_MASK_2;      
     
      if ((gTimer5Status & BM_TIMER5COMPARETRUE)) ATA_FlashApplTimer5Process_C();      
      if (gPCINTStatus & BM_PCINT1TRUE) ATA_RKEtimerStart();//Process Pin Change RKE intrs
      
      
      
      if (LF_DecErrFlag ==0x01)
      {
          
        // LF wake-up and data was received 
        ATA_CheckLfData_flash_C();
        
        // Check which LF wake-up ID was received
        if (ID0_Wake == 0x01)
        {
          // vehicle ID received
          app_peps_handler(RX_CHAN_LF0);
        }
        else 
        {
          // broadcast ID received
          app_peps_handler(RX_CHAN_LF1);
        }
        
        T0CR = 0;
        
        // PORTD |= (1<<1);   // Set PD3 high (LED1)
        PORTC |= (1<<0);   // Set PC0 high (LED1)
        
        for (char i=0; i<250; i++)
        {
          __delay_cycles(3500);    //Tout=1E06 Clks
        }
        //  PORTD &= ~(1<<1);     // Set PD3 low
        PORTC &= ~(1<<0);     // Set PD3 low
        
        ATA_lfRxEnableWakeup_flash_C(LFRX_BDR_3_90,LFRX_H_SENSE);
        //        ATA_lfRxEnableWakeup_flash_C(LFRX_BDR_3_90,LFRX_L_SENSE);
      }
      
      if (((gFlashApplState.Buttons & BM_BUTTONPROCCESSINGACTIVE)==0) && ((gFlashApplState.Buttons & BM_NEWCMNDVALID)))  //New Button press command available
      {
        bit_set(LED1);       
        ATA_Flash_RKEbuttonProcessOut();      
      }
      
//      ATA_globalsClkSwitchMrc_C();
     g_bSleepModeConfig_flash = POWER_DOWN;    // Set Sleep Mode
     
      /* Check whether sleep mode can be entered. */
     if (
                (        (g_sRfTx.bStatus & BM_RFTXCONFIG_BSTATUS_ACTIVE) == 0x00U)              &&
                (  (g_sAta5700_flash.status & BM_ATA5700_STATUS_SPI_CMD_IN_PROGRESS_FLAG) == 0x00U) &&
                (  (gFlashApplState.Buttons & BM_BUTTONPROCCESSINGACTIVE) != BM_BUTTONPROCCESSINGACTIVE) &&
                (   (gFlashApplState.State & BM_PEPSRFTIMERACTIVE) ==0x00)
             
          )
      {
        
        if ( (g_bSleepModeConfig_flash & BIT_MASK_0) != 0x00U )
        {
//          ATA_globalsSwitchMvccRegulator_C(FALSE);       // deactivate Vmem
          /*Enter Sleep using g_bSleepModeConfig_flash variable*/
          ATA_globalsSleep_C(g_bSleepModeConfig_flash);
          
          /* Disable Sleep */
          g_bSleepModeConfig_flash &= ~BIT_MASK_0;
        }
      }
    }
}









