/* *C**************************************************************************
  Use of this software is subject to Atmel's Software License Agreement.
-------------------------------------------------------------------------------
  $URL: http://svnservulm.corp.atmel.com/svn/CDB/Apps/SW_Lib/Car_Access/CARS_GEN2/ATAB5702A/Branches/P2_Gen2_Merge/appl/appFlash/src/FlashApplPEPS.c $
  $LastChangedRevision: 357549 $
  $LastChangedDate: 2015-12-16 02:04:47 +0800 (周三, 16 十二�?2015) $
  $LastChangedBy: mhahnen $
-------------------------------------------------------------------------------
  Project:      ATA5700
  Target MCU:   ATA5700
  Compiler:     IAR C/C++ Compiler for AVR 5.51.0
-------------------------------------------------------------------------------

*******************************************************************************
* Copyright 2011, Atmel Automotive GmbH                                       *
*                                                                             *
* This software is owned by the Atmel Automotive GmbH                         *
* and is protected by and subject to worldwide patent protection.             *
* Atmel hereby grants to licensee a personal,                                 *
* non-exclusive, non-transferable license to copy, use, modify, create        *
* derivative works of, and compile the Atmel Source Code and derivative       *
* works for the sole purpose of creating custom software in support of        *
* licensee product to be used only in conjunction with a Atmel integrated     *
* circuit as specified in the applicable agreement. Any reproduction,         *
* modification, translation, compilation, or representation of this           *
* software except as specified above is prohibited without the express        *
* written permission of Atmel.                                                *
*                                                                             *
* Disclaimer: ATMEL MAKES NO WARRANTY OF ANY KIND,EXPRESS OR IMPLIED,         *
* WITH REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED    *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.         *
* Atmel reserves the right to make changes without further notice to the      *
* materials described herein. Atmel does not assume any liability arising     *
* out of the application or use of any product or circuit described herein.   *
* Atmel does not authorize its products for use as critical components in     *
* life-support systems where a malfunction or failure may reasonably be       *
* expected to result in significant injury to the user. The inclusion of      *
* Atmel products in a life-support systems application implies that the       *
* manufacturer assumes all risk of such use and in doing so indemnifies       *
* Atmel against all charges.                                                  *
*                                                                             *
* Use may be limited by and subject to the applicable Atmel software          *
* license agreement.                                                          *
******************************************************************************/

/** \file FlashApplPEPS.c
    this file contains an ATA5700 Flash application software
*/

/*===========================================================================*/
/*  INCLUDES                                                                 */
/*===========================================================================*/
#include "../../../firmware/init/src/init.h"
#include "../../../firmware/rftx/src/rftx.h"
#include "../../../firmware/lfrx/src/lfrx.h"
#include "../../../firmware/spi/src/ata5700_command_set_flash.h"

#include "../../../firmware/init/src/init_flash.h"
#include "../../../firmware/system/src/system_flash.h"

#include "../../../firmware/timer1/src/timer1.h"
#include "../../../firmware/globals/src/globals.h"

#include "../../../firmware/lfrx/src/lfrx_flash.h"
#include "../../../firmware/tp/src/tp_flash.h"

#include "../../../firmware/extif/src/extif_flash.h"

#include "../../../firmware/lfrssi/src/lfrssi.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"

#include "../../../firmware/calib/src/calib.h"
#include "../../../firmware/eep/src/eep.h"

#include "../src/FlashApplPEPS.h"
#include "../src/FlashApplLF.h" 
#include "../src/micro.h"

#include "../src/FlashApplVars.h"
#include "FlashApplMSG.h"
#include <stdbool.h>

/*===========================================================================*/
/*  DEFINES                                                                  */
/*===========================================================================*/

#define MSG_RX_DATA (g_MsgRXbuffer.aub_data)
/*===========================================================================*/
/*  Modul Globals                                                             */
/*===========================================================================*/
uint8_t gLfMessageReceived; 
uint8_t gLfRxData[CFG_LF_BUFFER_SIZE];           // max LF buffer size = 32 bytes
uint8_t gLfNmbrRxByts;
uint16_t gExtLfRssi[3];
uint16_t gIntLfRssi[3];
uint16_t gLfRssiRes[3]; 
uint16_t wLfRssiref[3];
uint16_t wLfRssiNorm[3];
uint16_t wBref;
uint8_t gRSSI_ResBuffer[6];
uint8_t g3dVector[2];
uint8_t g3dVectorLin[2];
uint8_t gAES_DataBuffer[16];
uint8_t gVbat_Status; 

#pragma location = ".sram_FlashApp_MsgTXbuffer"
__no_init RFMSG_FRAME_TS g_MsgTXbuffer;

#pragma location = ".sram_FlashApp_MsgRXbuffer"
__no_init RFMSG_FRAME_TS g_MsgRXbuffer;


//RFMSG_FRAME_TS msg_rx_buffer;
//RFMSG_FRAME_TS msg_tx_buffer;

// command ID received
uint8_t rub_cid;

// information on source message (channel LF/RF and wake-up id)
uint8_t rub_wuip;

// Fob Index
uint8_t rub_fob_idx;

// Fob ID
uint32_t rul_fob_id; //KarM_CH_20160115_change to 32bits FOB ID;

// RF channel to use
uint8_t rub_rf_chan;

//uint8_t gBattStatus; 
uint8_t gNTE_DIAG_MODE;

VOIDFUNC ATA_lfRxEnableWakeup_flash_C(uint8_t bLfBdrate,uint8_t bSense);
VOIDFUNC ATA_CheckLfData_flash_C(void);
VOIDFUNC Init_LfRssi_flash_C(void);
VOIDFUNC ATA_PerformLfRSSI_flash_C(uint8_t bmode, uint8_t bsign);
extern VOIDFUNC ATA_StartRssi_flash_C(void);
VOIDFUNC ATA_lFRssiGetResult_flash_C(uint8_t bmode, uint8_t bsign);
static VOIDFUNC ATA_GetIntRssiValues(void);
VOIDFUNC app_rssi_set_ref(bool IntMeasure);
VOIDFUNC app_peps_handler(uint8_t lub_channel);
static VOIDFUNC _app_peps_task(void);
bool _peps_cmd_validity(void);
// Build PEPS RF message
static void _peps_build_msg(void);

extern void memory_copy(uint8_t*, uint8_t*, uint8_t);
extern bool memory_compare(uint8_t*,uint8_t*,uint8_t);
extern void memory_set(uint8_t* lpub_dst,
                       uint8_t lub_value, 
                       uint8_t lub_length);
extern void memory_copy_const(uint8_t* lpub_dst,
                              const uint8_t* lpub_src,
                              uint8_t lub_length);
extern bool memory_compare_const(uint8_t* lpub_src1,
                                    const uint8_t* lpub_src2,
                                    uint8_t lub_length);


extern VOIDFUNC app_rssi_load_factors(void);
extern VOIDFUNC ATA_StartRssi_flash_C(void);
extern VOIDFUNC CalcLinVector(void);

extern sEepFlashApp_RKEPEPS g_sEepFlashApp_RKEPEPS;


//Command with LF CW ?

uint8_t cabb_cmd_with_cw[16] =
{
  FALSE, //PEPS_CID_Read_UID
  FALSE, //PEPS_CID_RD_PARAM  1
  FALSE, //PEPS_CID_WR_PARAM  2
  FALSE,
  TRUE,  //PEPS_CID_2WAY     4
  TRUE,  //PEPS_CID_UNI_AUTH 5
  TRUE,  //PEPS_CID_BI_AUTH  6
  TRUE,  //PEPS_CID_UNI_AUTH_SING 7
  TRUE,  //PEPS_CID_BI_AUTH_SING  8
  FALSE,
  TRUE,  //PEPS_CID_LF_TST   10
  TRUE, //PEPS_CID_SET_REF  11
  FALSE,
  FALSE,
  FALSE, //PEPS_CID_SWID 14
  FALSE  //PEPS_CID_MODE 15
};

// Access codes for diagnostic (OEM, AS)
static CONST uint8_t caub_diag_code[2][4] =
{
  {
    (CFG_APP_OEM_CODE>>24)&0xFF,
    (CFG_APP_OEM_CODE>>16)&0xFF,
    (CFG_APP_OEM_CODE>>8)&0xFF,
    (CFG_APP_OEM_CODE&0xFF)
  },
  {
    (CFG_APP_AS_CODE>>24)&0xFF,
    (CFG_APP_AS_CODE>>16)&0xFF,
    (CFG_APP_AS_CODE>>8)&0xFF,
    (CFG_APP_AS_CODE&0xFF)
  }
};

/* Software identifiers */
#ifdef CFG_APP_2WAYRF
const uint8_t SW_ID[]={0x41,0x21,0x78/*Pro*/,0x15/*key*/,0x02/*App*/,0x20/*Rev*/};        //MiHa: could be changed
#else // ONE_WAY
const uint8_t SW_ID[]={0x41,0x20,0x99/*Pro*/,0x15/*key*/,0x01/*App*/,0x20/*Rev*/};        //MiHa: could be changed
#endif

NO_INIT_DATA CRAM_TS rts_cram;


/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/


/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/

//-----------------------------------------------------------------------------
/** \brief <b>ATA_lfRxEnableWakeup_flash_C</b>
    Shall configure the 3D LF receiver into LF listen mode and activate
      the ID0 wake-up interrupt

    \param[in]  bLfBdrate       selects the LF baud rate
                bSense          selects the LF RX sensitivity
                pLf_Id          pointer to the LF wake-up ID
                bLf_IdLength    number of LF ID bits

    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
void ATA_lfRxEnableWakeup_flash_C(uint8_t bLfBdrate,uint8_t bSense)
{
  uint8_t laub_data[4];
  
  LDFCKSW |= (1<<LDFSCSW); 
  while ((LDFCKSW & (1<<LDFSCKS)) ==0);            // wait until clock source is switched
 

  LFQC1 = LFRX_R_Trim90k;
  LFQC2 = LFRX_R_Trim90k;
  LFQC3 = LFRX_R_Trim117k;
  LFCR0 = 0x80 | bLfBdrate | BM_LFCE1 | BM_LFCE2 | BM_LFCE3;    // activate all channels and set baudrate
  LFCR1 = BM_LFRE | BM_LFPEEN;                              // enable RX, ID and Data Mode
  LFCR2 = bSense;                                        // select sensitivity
  //LFCR3 = ;                                            // at first without trimming function
  LDFFL =0x80;
  
  #ifdef CFG_LF_WUP0_IN_EEPROM
  // Wake-up ID stored in EEprom as a buffer (MSB first)
  ATA_eepReadBytes_C(laub_data, CFG_LF_WUP0_Adr, 0x04 );
 
  
  PHID00 = laub_data[(CFG_LF_WUP0_LENGTH/8-1)%4];//2
  PHID01 = laub_data[(CFG_LF_WUP0_LENGTH/8-2)%4];//1
  PHID02 = laub_data[(CFG_LF_WUP0_LENGTH/8-3)%4];//0
  PHID03 = laub_data[(CFG_LF_WUP0_LENGTH/8)%4];//3
  
#else
  // Wake-up ID stored in RAM or Flash
  PHID00 = (CFG_LF_WUP0) & 0xFF;
  PHID01 = (CFG_LF_WUP0>> 8) & 0xFF;
  PHID02 = (CFG_LF_WUP0>>16) & 0xFF;
  PHID03 = (CFG_LF_WUP0>>24) & 0xFF;
#endif

  //Low Frequency IDentifier 1 data register (LFID1)
#ifdef CFG_LF_WUP1_IN_EEPROM
  // Wake-up ID stored in EEprom as a buffer (MSB first)
  ATA_eepReadBytes_C(laub_data, CFG_LF_WUP1_Adr);
  PHID10 = laub_data[(CFG_LF_WUP1_LENGTH/8-1)%4];
  PHID11 = laub_data[(CFG_LF_WUP1_LENGTH/8-2)%4];
  PHID12 = laub_data[(CFG_LF_WUP1_LENGTH/8-3)%4];
  PHID13 = laub_data[(CFG_LF_WUP1_LENGTH/8)%4];
#else
  // Wake-up ID stored in RAM or Flash
  PHID10 = (CFG_LF_WUP1) & 0xFF;
  PHID11 = (CFG_LF_WUP1>> 8) & 0xFF;
  PHID12 = (CFG_LF_WUP1>>16) & 0xFF;
  PHID13 = (CFG_LF_WUP1>>24) & 0xFF;
#endif
  
  
  // Settings for the protocol handler
 
  PHID0L = CFG_LF_WUP0_LENGTH;
  PHID1L = CFG_LF_WUP1_LENGTH;
  PHIDFR = LF_IDFRAMELENGTH;
  
  PHTBLR = 0xFF;                // Protocol Handler Telegram bit length
//  PHDFR = 48;
  
  LFSYSY0 = 0x09;               //Define wakeup ID pattern;
  LFSYLE = 0x04;
  
  PHIMR |= BM_PHID0IM | BM_PHID1IM;       // enable both wake-up ID interrupt
  
  LDFC = (1<<LDFMSB) | 5;//KarM_Data Fifo setting

  //Enable PB3/LFES as a debug port
  //DBGSW = 10;                       // Enable to drive debug test 10
  
  //LTEMR |= (1<<EOFEM);                // End of telegram triggers timer 
  //LDFIM |= (1<<LDFFLIM);                // fill level int.
 // LFIMR |= (1<<LFEOIM);                 // enable EOF int for LF 
  
  /*-- gr new */
  //PRR1 |= (1<<PRLFR);                 //Power reduction setting
  //LFIMR |= (1<<LFSYDIM);              //LF receive IRQ mask;
  //LFIMR |= (1<<LFDEIM); 
  /*-- end new */
  ID0_Wake = 0x00;
  ID1_Wake = 0x00;
  LF_DecErrFlag = 0x00; 
}


//-----------------------------------------------------------------------------
/** \brief <b>Init_LfRssi_flash_C</b>
    Prepare LF RSSI block for measurements
    

    \param[in]  none


    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
VOIDFUNC Init_LfRssi_flash_C(void)
{
  /* Temp. initialization of LF RSSI component data for use during System
  Verification */
  g_sLfRssi.bFlags = 0;
  g_sLfRssi.bStatus = 0;
  
  ATA_lfRssiInit_C();
  
  ATA_lfRssiMeasConfig_flash_C(PARALLEL_LFRSSI_MEASUREMENT);
  
}

//-----------------------------------------------------------------------------
/** \brief <b>ATA_PerformLfRSSI_flash_C</b>
    Contains the complete flow for performing an LF RSSI measurement
    

    \param[in]  bMode       Contains internal or external LF RSSI measurement request


    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
VOIDFUNC ATA_PerformLfRSSI_flash_C(uint8_t bmode, uint8_t bsign)
{
  ATA_StartRssi_flash_C();
  
  ATA_lfRssiMeasStart_C( &g_sLfRssiRegConfig_flash, bmode, bsign );
  do 
  {
    
  }
  while ((g_sLfRssi.bStatus & LFRSSI_STATUS_BM_MEAS_DATA_AVAILABLE_FLAG)==0); 
  
  ATA_lFRssiGetResult_flash_C(bmode, bsign);             

}

//-----------------------------------------------------------------------------
/** \brief <b>ATA_CheckLfData_flash_C</b>
    Reads out the received LF telegram from the internal LF data buffer
    

    \param[in]  none


    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
VOIDFUNC ATA_CheckLfData_flash_C(void)
{
  uint8_t index;
  
  LDFCKSW |= (1<<LDFSCSW); 
  while ((LDFCKSW & (1<<LDFSCKS)) ==0);            // wait until clock source is switched
  gLfNmbrRxByts = LDFFL; 
  if (gLfNmbrRxByts !=0)
  {
    for (index=0; index < gLfNmbrRxByts; index++)
    {
      //gLfRxData[index + 4] = LDFD;
      //g_MsgRXbuffer.aub_data[index + 4] = LDFD;
      g_MsgRXbuffer.aub_data[index + 3] = LDFD;//KarM_CH_20160115_VID is only 3 bytes, so here start from 3;
    }
    g_MsgRXbuffer.ub_size = gLfNmbrRxByts;
  }
  LDFCKSW &= ~(1<<LDFSCSW);
  

}


/**
 * \brief Update internal reference (compensation factor) in EEprom
 *        Values stored in raub_lf_rssi[LF_MEAS_INT] are used
 *
 * \param[in] lbb_with_acq TRUE execute an internal RSSI measurements and update
 *                         raub_lf_rssi[LF_MEAS_INT] before updating EEprom
 *                         FALSE otherwise
 *
 * \return void
 */
VOIDFUNC app_rssi_set_ref(bool IntMeasure)
{
  if (IntMeasure == TRUE)
  {
  // acquire RSSI internal
  Init_LfRssi_flash_C();
  ATA_PerformLfRSSI_flash_C(LFRSSI_INT, NO_SIGNDET);
  }
  
  // Store RSSI in EEProm
  ATA_eepWriteBytes_C( (uint8_t*)LF_RSSI_INTREF_X, gIntLfRssi[LF_AXIS_X],2);
  ATA_eepWriteBytes_C( (uint8_t*)LF_RSSI_INTREF_Y, gIntLfRssi[LF_AXIS_Y],2);
  ATA_eepWriteBytes_C( (uint8_t*)LF_RSSI_INTREF_Z, gIntLfRssi[LF_AXIS_Z],2);
  
}


/**
 * \brief PEPS Task on frame reception
 *        Start LF RSSI acquisiotns if needed
 *        Check WUID is coming from RF link
 *        Call PEPS handler
 *
 * \return none
 */
void app_peps_handler(uint8_t lub_channel)
{
//  uint8_t laub_data[4];
  uint8_t bMargin; 
   
  // accept only frames with more than 5 bytes (WUID + CID + CKS)
  if (gLfNmbrRxByts >= 5)               //MiHa muss noch pr�fen ob dies richtig ist
  {
    // get CID
    //rub_cid = ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->cid;
    //rub_cid = ((g_MsgRXbuffer.aub_data[4]& BM_CID)>>4);           // contains cmd and key
    rub_cid = ((g_MsgRXbuffer.aub_data[3]& BM_CID)>>4);           // KarM_CH_20160115_CID is loacted in byte 3;
    rub_wuip = lub_channel;
    
    if (rub_wuip&RX_CHAN_LF_MSK)
    { 
      // message received by LF
      rub_wuip |= (rub_wuip<<3);    // set WUID source
      // RSSI acquisitions ?
      if (cabb_cmd_with_cw[rub_cid])
      {
        // acquire internal RSSI (CW OFF)
        Init_LfRssi_flash_C();
        ATA_PerformLfRSSI_flash_C(LFRSSI_INT, NO_SIGNDET);
        // wait before external field measurement
        //TIMEB_WAIT_US((16-CFG_LF_RSSI_ACQ)*100);   //MiHa delay must be added to get to the start of CW
        // acquire external RSSI (CW ON)
        
        ATA_PerformLfRSSI_flash_C(LFRSSI_EXT, NO_SIGNDET);

//        ATA_eepReadBytes_C(&bMargin, MARGIN_EEADR, 0x01);
//        ATA_eepReadBytes_C((uint8_t*)&wLfRssiref[0], LFRSSIREF_EEADR, 0x02);
//        ATA_eepReadBytes_C((uint8_t*)&wLfRssiNorm[0], LFRSSINORM_EEADR, 0x02);
//        ATA_lfRssiCalcChanCalibVal_C(bMargin, &wLfRssiref[0],&wLfRssiNorm[0]);
//        ATA_lfRssiCalcCorr_C();
      }
      // force emission on channel 1 when command is received by LF
      rub_rf_chan = 0; //Toby - was 1
    }
    else
    {
//      // message received by RF
//      // Note: ATA5831 returns 1 additionnal byte due to additionnal bit in EOF
//      msg_rx_buffer.ub_size -= 1;
//      
//      // check if wake-up ID match WUID0
//#ifdef CFG_LF_WUP0_IN_EEPROM    
//      EEPDATA_READ(laub_data, CFG_LF_WUP0);
//#else
//      laub_data[3] = (CFG_LF_WUP0>>((CFG_LF_WUP0_LENGTH-32)&0x1F)) & 0xFF;
//      laub_data[2] = (CFG_LF_WUP0>>((CFG_LF_WUP0_LENGTH-24)&0x1F)) & 0xFF;
//      laub_data[1] = (CFG_LF_WUP0>>((CFG_LF_WUP0_LENGTH-16)&0x1F)) & 0xFF;
//      laub_data[0] = (CFG_LF_WUP0>>((CFG_LF_WUP0_LENGTH-8)&0x1F)) & 0xFF;
//#endif
//      if (memory_compare(((RX_MSG_PEPS_TS*)MSG_RX_DATA)->vid,
//                          laub_data, CFG_PEPS_VID_LENGTH))
//      {
//        rub_wuip = RX_WUID0;
//      }
//      
//      // check if wake-up ID match WUID1
//#ifdef CFG_LF_WUP1_IN_EEPROM    
//      EEPDATA_READ(laub_data, CFG_LF_WUP1);
//#else
//      laub_data[3] = (CFG_LF_WUP1>>((CFG_LF_WUP0_LENGTH-32)&0x1F)) & 0xFF;
//      laub_data[2] = (CFG_LF_WUP1>>((CFG_LF_WUP0_LENGTH-24)&0x1F)) & 0xFF;
//      laub_data[1] = (CFG_LF_WUP1>>((CFG_LF_WUP0_LENGTH-16)&0x1F)) & 0xFF;
//      laub_data[0] = (CFG_LF_WUP1>>((CFG_LF_WUP0_LENGTH-8)&0x1F)) & 0xFF;
//#endif
//      if (memory_compare(((RX_MSG_PEPS_TS*)MSG_RX_DATA)->vid,
//                         laub_data, CFG_PEPS_VID_LENGTH))
//      {
//        rub_wuip = RX_WUID1;
//      }
    }
    // LF_ENABLE(FALSE);   //hier sollte jetzt die Berechnung gemacht werden und dann kann der LF ausgeschalten werden
    
//    if (rub_wuip&RX_WUID_MSK)
//    {
      _app_peps_task();         
//    }
  }
}

//-----------------------------------------------------------------------------
/** \brief <b>ATA_lFRssiGetResult_flash_C<void>
    Read out the result from the last LF RSSI measurements and store them 
      to the global variables

    \param[in] none

    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/

void ATA_lFRssiGetResult_flash_C(uint8_t bmode, uint8_t bsign)
{

  RSMS1R &= ~(1<<RSSSV);        // for output the everage value
  if (bmode == 0)
  {
    gExtLfRssi[0] = (RSRES1H<<8) ;
    gExtLfRssi[0] |= RSRES1L;
    gExtLfRssi[1] = (RSRES2H<<8) ;
    gExtLfRssi[1] |= RSRES2L;
    gExtLfRssi[2] = (RSRES3H<<8) ;
    gExtLfRssi[2] |= RSRES3L;
    
  }
  else 
  {
    gIntLfRssi[0] = (RSRES1H<<8) ;
    gIntLfRssi[0] |= RSRES1L;
    gIntLfRssi[1] = (RSRES2H<<8) ;
    gIntLfRssi[1] |= RSRES2L;
    gIntLfRssi[2] = (RSRES3H<<8) ;
    gIntLfRssi[2] |= RSRES3L;
  }
}



/**
 * \brief PEPS common Task
 *        Analyse and execute frame receive
 *        Prepare RF message reply
 *        Send RF message reply
 *        Acquire battery status
 *        Light ON LED for 50ms
 *
 * \return none
 */
static void _app_peps_task(void)
{
  // execute command
  if (_peps_cmd_validity())
  
  {
    // light on LED
    bit_set(LED1);
    
//#ifdef CFG_APP_2WAYRF
//    // wake-up RF
//    rf_ata5831_setmode(E_STATE_IDLE, (RF_ATA5831_CONFIG_TU){0});
//#else // ONE WAY
//    // start XTO quartz now so that it is stabilized when we need to transmit
//    rf_ata5791_setmode(RF_MODE_IDLE);
//#endif

    // Build RF message
    _peps_build_msg();     

    //activate voltage monitor
    PRR0 &= ~BM_PRVM;  //remove power reduction on voltage monitor  
    VMSCR |= BM_VMF; // clear VMF flag
    VMCR = BM_VM_VBAT | BM_VM_2_1V; 
    
    
    //load up the data message to be tested
    for (uint8_t index = 0; index < (CFG_PEPS_PREAMBLE_LENGTH-1); index++)
    {
      MSG_TX_DATA.peps.preamble0[index]=0xff;
    }     
    MSG_TX_DATA.peps.preamble1 = 0xfe;
    

    // Send RF message
    ATA_rfTx_PEPSmsg_flash_C();       //MiHa is done by George
   

    // update battery flag
    gVbat_Status = (VMSCR & ~BM_VMF);

    // stop voltage monitor
    VMCR = BM_VM_DISABLE;
    PRR0 |= (1<<PRVM);

    // must be checked if delay must be added
    bit_clear(LED1);
  }
}



/**
 * \brief Verify LF frame command validity
 *        Check managed CID, Frame lenght, CRC if any, WUP ID used, Diag mode
 *        Command parameter (with cyphered challenge in case of bilateral authent)
 *
 * \return TRUE if command is valid, FALSE otherwise
 */
static bool _peps_cmd_validity(void)
{
  uint16_t AES_KeyAddr; 
  // init global variables
  ATA_eepReadBytes_C((uint8_t*)&rub_fob_idx, (uint16_t)&eub_fidx, 0x01);
  //ATA_eepReadBytes_C((uint8_t*)&rul_fob_id, eul_key_id, 0x01);
  ATA_eepReadBytes_C((uint8_t*)&rul_fob_id, eul_key_id, 0x04);//KarM_CH_20160115_4 bytes FOB ID should be read out;
  
  // check wake-up ID source
  switch (rub_cid)
  {
    case PEPS_CID_WR_PARAM:
    case PEPS_CID_RD_PARAM:
      if ((rub_wuip&RX_WUID_MSK) == RX_WUID1)
      {
        // wrong wake-up or wrong index
        return FALSE;
      }
      else if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx != rub_fob_idx)
      {
        // wrong fob index
        return FALSE;
      }
      break;

    case PEPS_CID_2WAY:
      // allowed everytime
      break;
      
    case PEPS_CID_UNI_AUTH_SINGLE:
    case PEPS_CID_BI_AUTH_SINGLE:
      if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx != rub_fob_idx)
      {
        // wrong fob index
        return FALSE;
      }
    case PEPS_CID_UNI_AUTH:
    case PEPS_CID_BI_AUTH:
      if ((rub_wuip&RX_WUID_MSK) == RX_WUID1)
      {
        // wrong wake-up
        return FALSE;
      }
      break;
      
    default:
      if ((rub_wuip&RX_WUID_MSK) == RX_WUID0)
      {
        // vehicle wake-up
        if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx != rub_fob_idx)
        {
          // wrong fob index
          return FALSE;
        }
      }
  }

  // check mode
  switch (rub_cid)
  {
    case PEPS_CID_RD_PARAM:
    case PEPS_CID_WR_PARAM:
      if (gNTE_DIAG_MODE == DIAG_OFF)
      {
        // forbiddden in DIAG OFF
        return FALSE;
      }
      break;

    case PEPS_CID_LF_PARAM:
      if (gNTE_DIAG_MODE != DIAG_OEM)
      {
        // only allowed in OEM mode
        return FALSE;
      }
      break;
      
    default:
      break;
  }

  // check CRC
  //Not needed with ATA5702 as we want to use the internal CRC hardware for all commands
  // messages with wrong CRC will automatically ignored. 
//  if ((rub_cid < PEPS_CID_UNI_AUTH) || (rub_cid > PEPS_CID_BI_AUTH_SINGLE))
//  { /// only for non auth commands
// 
// 
//    //**
//    g_MsgRXbuffer.ub_size = 0x01;
//    
//    
//    if ((msg_rx_buffer.aub_data)[(msg_rx_buffer.ub_size)-1] !=   
//        crc_compute(MSG_RX_DATA+CFG_PEPS_VID_LENGTH, 
//                   MSG_RX_CNT-CFG_PEPS_VID_LENGTH-1,
//                    CRC_INIT_00,
//                    CRC_POLY_CCIT))
//    {
//      return FALSE;
//    }
//  }

  // check command parameters
  switch (rub_cid)
  {
    case PEPS_CID_RD_PARAM:
    case PEPS_CID_WR_PARAM:
      
      //**
      if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_rd_param.param_index >=32)
      {
        // wrong parameter index
        return FALSE;
      }
      break;

    case PEPS_CID_BI_AUTH:
    case PEPS_CID_BI_AUTH_SINGLE:
      // check cyphered challenge
      //     TIMEB_CLK_SPEED(CLK_SPEED_FULL);  //MiHa: not needed with ATA5702
      // load AES Key
      //     EEPDATA_READ(raub_aes_keyin_cyphout, eaub_aes_key_vehicle); //MiHa: not needed with ATA5702 
      // load challenge and cypher it
      
      PRR0 &= ~BM_PRCU;         //disable power reduction for AES
      AESCR = BM_AESRES;
      ATA_eepReadBytes_C((uint8_t*)&AES_KeyAddr, AESKEYPOINTERB, 0x02); 
      ATA_aesTriggerKeyDma_C(AES_KeyAddr);
      __delay_cycles(30);
      memory_copy(&gAES_DataBuffer[0], (uint8_t*)((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_auth_bi.challenge + 1, CFG_PEPS_CHALLENGE_LENGTH);
      for (uint8_t index = CFG_PEPS_CHALLENGE_LENGTH; index < 16; index++)
      {
        //gAES_DataBuffer[index] = AES_PADD_PATTERN;
        gAES_DataBuffer[index] = gAES_DataBuffer[(index & 3)]; 
      }
      ATA_aesLoadData_C(&AESDR, &gAES_DataBuffer[0]);
      AESCR = BM_AESE; 
      while ((AESSR & BM_AESRF)== 0x00U);       //wait until ready
      AESSR |= BM_AESRF;                        // clear flag
      for (uint8_t index = 0; index < 16; index++)
      {
        gAES_DataBuffer[index] = AESDR;
      }
      PRR0 |= BM_PRCU;         //enable power reduction for AES
      
      // compare challenge cyphered with the on received
      if (!memory_compare(&gAES_DataBuffer[0],
                          (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_auth_bi.cyph_challenge + 1),
                          CFG_PEPS_CHALLENGE_CYPH_LENGTH))
      {
        return FALSE;
      }
      break;

    case PEPS_CID_MODE:
      // check FOB ID
      if (rul_fob_id != ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_mode.fid)
      {
        // wrong ID
        return FALSE;
      }
      break;
      
    default:
      break;
  }

  return TRUE;
}

/**
 * \brief Execute command and build PEPS RF message
 *        RF message is stored in MSG_TX_DATA variable
 *        Authent : compute AES and RSSI values
 *        Write param: update param in EEprom
 *        LF test: compute RSSI
 *        LF param: update parameters in EEprom
 *        Mode: change DIAG mode
 *
 * \return void
 */
static void _peps_build_msg(void)
{
  uint32_t* lpul_id;
  uint16_t AES_KeyAddr; 


  
  // common message data
  memory_set(MSG_TX_DATA.rke.preamble0, 0x00, CFG_RKE_PREAMBLE_LENGTH-1);
  MSG_TX_DATA.peps.preamble1 = 0x01;
  MSG_TX_DATA.peps.fidx = rub_fob_idx&0x07;//KarM_CH_20160115_define the FOB_Idx
  MSG_TX_DATA.peps.bat = gVbat_Status;
  MSG_TX_DATA.peps.cid = rub_cid;

  // specific message data
  switch (rub_cid)
  {
    case PEPS_CID_RD_ID:
      MSG_TX_DATA.peps.data_id.fid = rul_fob_id;
      // read 4 bytes in every case, last bytes will be overwritte by cks
      ATA_eepReadBytes_C((uint8_t*)&MSG_TX_DATA.peps.data_id.vid, (uint16_t)&eaub_vid, VID_LENGTH); 
      break;

    case PEPS_CID_UNI_AUTH:
    case PEPS_CID_BI_AUTH:
    case PEPS_CID_UNI_AUTH_SINGLE:
    case PEPS_CID_BI_AUTH_SINGLE:
      CalcLinVector();
      //KarM_CH_20160115_remove rssil for testing;
      //MSG_TX_DATA.peps.data_authent.rssil = g3dVectorLin[0]; 
      MSG_TX_DATA.peps.data_authent.rssih = g3dVectorLin[1]; 
      

      // compute MAC
      // load AES key
      PRR0 &= ~BM_PRCU;         //disable power reduction for AES
      AESCR = BM_AESRES;
      //AESKEYPOINTERB --> 0x84A,but 0x084A is 0xFF, it should point to address:0x0780
      //ATA_eepReadBytes_C((uint8_t*)&AES_KeyAddr, AESKEYPOINTERB, 0x02); //MiHa: Check if right key is loaded
      ATA_eepReadBytes_C((uint8_t*)&AES_KeyAddr, AESKEYPOINTERA, 0x02);//KarM_CH_20160115_KEYA is used for Auth;KeyB is not defined in the EEP;

      ATA_aesTriggerKeyDma_C(AES_KeyAddr);

      // load message and cypher it
      //MiHa: check if below pointers are still pointing to the correct byte 
      memory_copy(MSG_TX_DATA.peps.data_authent.mac, 
                  ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_auth_uni.challenge,
                  CFG_PEPS_CHALLENGE_LENGTH);
      lpul_id = (uint32_t*)(MSG_TX_DATA.peps.data_authent.mac
                          +CFG_PEPS_CHALLENGE_LENGTH);
      *lpul_id = rul_fob_id;
            
      
      memory_copy(&gAES_DataBuffer[0], (uint8_t*)&MSG_TX_DATA.peps.data_authent-1, /*CID*/1+/*RSSI*/1+CFG_PEPS_CHALLENGE_LENGTH+/*FID*/4);
      for (uint8_t index = /*CID*/1+/*RSSI*/1+CFG_PEPS_CHALLENGE_LENGTH+/*FID*/4; index < 16; index++)
      {
        gAES_DataBuffer[index] = AES_PADD_PATTERN;
      }
      
      ATA_aesLoadData_C(&AESDR, &gAES_DataBuffer[0]);
      //compute AES
      AESCR = BM_AESE; 
      while ((AESSR & BM_AESRF)== 0x00U);       //wait until ready
      AESSR |= BM_AESRF;                        // clear flag
      for (uint8_t index = 0; index < 16; index++)
      {
        gAES_DataBuffer[index] = AESDR;
      }
      memory_copy(MSG_TX_DATA.peps.data_authent.mac,
                  &gAES_DataBuffer[0],
                  CFG_PEPS_CHALLENGE_LENGTH);
      PRR0 |= BM_PRCU;         //enable power reduction for AES

#ifdef CFG_APP_2WAYRF
      // enable ATA5831 communication back
      //MiHa PCINT_ENABLE(CFG_RF_ATA5831_INT, TRUE);
#endif      
      break;

    case PEPS_CID_WR_PARAM:
      // store parameter in EEprom
      ATA_eepWriteBytes_C(((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_wr_param.param_data,
                    eaub_param +(((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_wr_param.param_index)* 3 * PARAMBLOCK_SIZE, PARAMBLOCK_SIZE);
      // no break in switch case to send reply
    case PEPS_CID_RD_PARAM:
      // return VID
      // read 4 bytes in every case, but last byte may be overwritte by cks
      ATA_eepReadBytes_C((uint8_t*)&MSG_TX_DATA.peps.data_param.vid, (uint16_t)&eaub_vid, 4);      //MiHa: check if 4 is correct as VID length was set to 3
      // read parameter in EEprom
      ATA_eepReadBytes_C(&MSG_TX_DATA.peps.data_param.param_data[0],
                   eaub_param + (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_wr_param.param_index) * 3 * PARAMBLOCK_SIZE, PARAMBLOCK_SIZE);
      // complete message (index + checksum)
      MSG_TX_DATA.peps.data_param.param_index =
        ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_wr_param.param_index;
      break;

    case PEPS_CID_2WAY:
      CalcLinVector();
      MSG_TX_DATA.peps.data_2way.rssil = g3dVectorLin[0];
      MSG_TX_DATA.peps.data_2way.rssih = g3dVectorLin[1];
      // save rF channel for reply
      rub_rf_chan = (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx)>>1;
      // enable RF reception for 1s
//T      timeb_timer_start_s(CFG_TIMER_RFRX, 1);                           //MiHa must be changed
      // return msg already completed
      break;

    case PEPS_CID_LF_TST:
//T      MSG_TX_DATA.peps.data_lf_tst.rss = app_rssi_compute();              //MiHa: must be changed 
      MSG_TX_DATA.peps.data_lf_tst.norm_x = wLfRssiNorm[LF_AXIS_X];
      MSG_TX_DATA.peps.data_lf_tst.norm_y = wLfRssiNorm[LF_AXIS_Y];
      MSG_TX_DATA.peps.data_lf_tst.norm_z = wLfRssiNorm[LF_AXIS_Z];
      MSG_TX_DATA.peps.data_lf_tst.ref_x = wLfRssiref[LF_AXIS_X];
      MSG_TX_DATA.peps.data_lf_tst.ref_y = wLfRssiref[LF_AXIS_Y];
      MSG_TX_DATA.peps.data_lf_tst.ref_z = wLfRssiref[LF_AXIS_Z];
      MSG_TX_DATA.peps.data_lf_tst.ext_x = gExtLfRssi[LF_AXIS_X];
      MSG_TX_DATA.peps.data_lf_tst.ext_y = gExtLfRssi[LF_AXIS_Y];
      MSG_TX_DATA.peps.data_lf_tst.ext_z = gExtLfRssi[LF_AXIS_Z];
      MSG_TX_DATA.peps.data_lf_tst.int_x = gIntLfRssi[LF_AXIS_X];
      MSG_TX_DATA.peps.data_lf_tst.int_y = gIntLfRssi[LF_AXIS_Y];
      MSG_TX_DATA.peps.data_lf_tst.int_z = gIntLfRssi[LF_AXIS_Z];
      break;

    case PEPS_CID_LF_PARAM:
      // update normalization factors
      if ((((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.norm_x != 0xFF) ||
          (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.norm_y != 0xFF) ||
          (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.norm_z != 0xFF))
      {
        memory_copy((uint8_t*)&wLfRssiNorm[LF_AXIS_X], (uint8_t*)((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.norm_x, 2); //MiHa
        memory_copy((uint8_t*)&wLfRssiNorm[LF_AXIS_Y], (uint8_t*)((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.norm_y, 2);
        memory_copy((uint8_t*)&wLfRssiNorm[LF_AXIS_Z], (uint8_t*)((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.norm_z, 2);
      }

      // update compensation factors
      if ((((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_x == 0xFF) &&
          (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_y == 0xFF) &&
          (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_z == 0xFF))
      {
        // do not change compensation
      }
      else if ((((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_x == 0xFE) &&
               (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_y == 0xFE) &&
               (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_z == 0xFE))
      {
        // auto acquire new internal reference
        
        app_rssi_set_ref(TRUE);
      }
      else
      {
        // set new internal reference = data received                   //MiHa: not clear why this comes from the basestation
        gIntLfRssi[LF_AXIS_X] = ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_x;
        gIntLfRssi[LF_AXIS_Y] = ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_y;
        gIntLfRssi[LF_AXIS_Z] = ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_lf_param.ref_z;
        app_rssi_set_ref(FALSE);
      }

      app_rssi_load_factors();
      // fill RF message
      MSG_TX_DATA.peps.data_lf_param.norm_x = wLfRssiNorm[LF_AXIS_X];
      MSG_TX_DATA.peps.data_lf_param.norm_y = wLfRssiNorm[LF_AXIS_Y];
      MSG_TX_DATA.peps.data_lf_param.norm_z = wLfRssiNorm[LF_AXIS_Z];
      MSG_TX_DATA.peps.data_lf_param.ref_x = wLfRssiref[LF_AXIS_X];
      MSG_TX_DATA.peps.data_lf_param.ref_y = wLfRssiref[LF_AXIS_Y];
      MSG_TX_DATA.peps.data_lf_param.ref_z = wLfRssiref[LF_AXIS_Z];
      break;

    case PEPS_CID_SWID:
      // send Software ID
    
      memory_copy_const(MSG_TX_DATA.peps.data_swid.swid,
                        (const uint8_t*)SW_ID,
                        6);   
      break;

    case PEPS_CID_MODE:
      // check mode and code
      if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_mode.mode > 2)
      {
        // unknown mode, back to diag OFF
        NTE_DIAG_MODE = DIAG_OFF;
      }
      else if (memory_compare_const(
                 (uint8_t*)&((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_mode.code,
                 (const uint8_t*)caub_diag_code[((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_mode.mode-1],
                 4))
      {
        NTE_DIAG_MODE = (DIAG_MODE_TE)((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_mode.mode;
        // activate long timeout @8s to exit diag
//        timeb_timer_start_s(CFG_TIMER_MODE, 8);                 //MiHa must be changed
      }
      else
      {
        //wrong code
        NTE_DIAG_MODE = DIAG_OFF;
      }
      MSG_TX_DATA.peps.data_mode.fid = ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_mode.fid;
      MSG_TX_DATA.peps.data_mode.mode = (uint8_t)NTE_DIAG_MODE;
      break;
     
    default:
      break;
  }
  /* MiHa: I think this could be done automaticaly by the hardware
  // compute frame checksum
  if ((rub_cid < PEPS_CID_UNI_AUTH) || (rub_cid > PEPS_CID_BI_AUTH_SINGLE))
  {
    *((UINT8*)&MSG_TX_DATA.peps + caub_tx_length[rub_cid]-1) =
      crc_compute((UINT8*)&MSG_TX_DATA.peps + CFG_PEPS_PREAMBLE_LENGTH,
                  caub_tx_length[rub_cid]-(CFG_PEPS_PREAMBLE_LENGTH+1),
                  CRC_INIT_00,
                  CRC_POLY_CCIT);
  }
 */  
  /* MiHa: Is this needed??
  // rearm RFRX tieout if needed
  if (!IS_TIMER_ENDED(CFG_TIMER_RFRX))
  {
    timeb_timer_start_s(CFG_TIMER_RFRX, 1);
  }
 */
}

