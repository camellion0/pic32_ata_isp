/* *C**************************************************************************
  Use of this software is subject to Atmel's Software License Agreement.
-------------------------------------------------------------------------------
  $URL: http://svnservulm.corp.atmel.com/svn/CDB/Apps/SW_Lib/Car_Access/CARS_GEN2/ATAB5702A/Branches/GR_inwork/appl/appFlash/src/FlashIrq.c $
  $LastChangedRevision: 329346 $
  $LastChangedDate: 2015-07-27 16:45:01 -0600 (Mon, 27 Jul 2015) $
  $LastChangedBy: grueter $
-------------------------------------------------------------------------------
  Project:      ATA5700
  Target MCU:   ATA5700
  Compiler:     IAR C/C++ Compiler for AVR 5.51.0
-------------------------------------------------------------------------------

*******************************************************************************
* Copyright 2011, Atmel Automotive GmbH                                       *
*                                                                             *
* This software is owned by the Atmel Automotive GmbH                         *
* and is protected by and subject to worldwide patent protection.             *
* Atmel hereby grants to licensee a personal,                                 *
* non-exclusive, non-transferable license to copy, use, modify, create        *
* derivative works of, and compile the Atmel Source Code and derivative       *
* works for the sole purpose of creating custom software in support of        *
* licensee product to be used only in conjunction with a Atmel integrated     *
* circuit as specified in the applicable agreement. Any reproduction,         *
* modification, translation, compilation, or representation of this           *
* software except as specified above is prohibited without the express        *
* written permission of Atmel.                                                *
*                                                                             *
* Disclaimer: ATMEL MAKES NO WARRANTY OF ANY KIND,EXPRESS OR IMPLIED,         *
* WITH REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED    *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.         *
* Atmel reserves the right to make changes without further notice to the      *
* materials described herein. Atmel does not assume any liability arising     *
* out of the application or use of any product or circuit described herein.   *
* Atmel does not authorize its products for use as critical components in     *
* life-support systems where a malfunction or failure may reasonably be       *
* expected to result in significant injury to the user. The inclusion of      *
* Atmel products in a life-support systems application implies that the       *
* manufacturer assumes all risk of such use and in doing so indemnifies       *
* Atmel against all charges.                                                  *
*                                                                             *
* Use may be limited by and subject to the applicable Atmel software          *
* license agreement.                                                          *
******************************************************************************/

/** \file FlashApplIRQ.c
    this file contains an ATA5700 Flash application software
*/

/*===========================================================================*/
/*  INCLUDES                                                                 */
/*===========================================================================*/
#include "../../../firmware/init/src/init.h"
#include "../../../firmware/rftx/src/rftx.h"
#include "../../../firmware/lfrx/src/lfrx.h"
#include "../../../firmware/spi/src/ata5700_command_set.h"
#include "../../../firmware/stdc/src/ioATA5700.h"

#include "../../../firmware/init/src/init_flash.h"
#include "../../../firmware/system/src/system_flash.h"

#include "../../../firmware/timer1/src/timer1.h"
#include "../../../firmware/timer5/src/timer5_flash.h"
#include "../../../firmware/globals/src/globals.h"

#include "../../../firmware/lfrx/src/lfrx_flash.h"
#include "../../../firmware/tp/src/tp_flash.h"

#include "../../../firmware/extif/src/extif_flash.h"

#include "../../../firmware/lfrssi/src/lfrssi.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"

#include "../../../firmware/calib/src/calib.h"
#include "../../../firmware/aes/src/aes.h"
#include "FlashApplVars.h"


/*===========================================================================*/
/*  DEFINES                                                                  */
/*===========================================================================*/

/*===========================================================================*/
/*  Modul Globals                                                             */
/*===========================================================================*/
uint8_t guiButton =0;
uint8_t ButtonTimerCnt=0;
tTimer5Status gTimer5Status;
tPCINTStatus gPCINTStatus;
extern sFlashApplState gFlashApplState;
extern sFlashApplVars gFlashApplVars;


/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/

/*----------------------------------------------------------------------------- */
/*brief <b>PCINTO Interrupt handler</b>*/
            
/*    The function contains the interrupt vector for the Pin Change interrupts 0-7.
    This routine determins the specefic pin that generated the interupt and sets
    variables to alert the main loop that a new button press has been detected.*/
 
/*---------------------------------------------------------------------------*/
#pragma vector=PCINT1_vect
__interrupt VOIDFUNC ATA_pinChangeInterrupt1Handler_ISR_flash_C(void)
{
   gPCINTStatus |= BM_PCINT1TRUE;   
}
/*----------------------------------------------------------------------------- */
#pragma vector=T5COMP_vect
__interrupt VOIDFUNC ATA_timer5CompareMatchInterruptHandler_ISR_flash_C(void)
{
  gTimer5Status |= BM_TIMER5COMPARETRUE; 
}
/*----------------------------------------------------------------------------- */
#pragma vector=T5OVF_vect
__interrupt VOIDFUNC ATA_timer5OverflowInterruptHandler_ISR_flash_C(void)
{
  gTimer5Status |= BM_TIMER5OVERFLOWTRUE;  
}
/*------------------------------------------------------------------------------*/
void ATA_RKEtimerStart()
{
   gPCINTStatus &= ~(BM_PCINT1TRUE);//Clear the flag
   Intr_Disable(SW1_INTR);    //Disable SW1,2,3 interrupts 
   Intr_Disable(SW2_INTR);
   Intr_Disable(SW3_INTR);
   gFlashApplState.Buttons |=  BM_BUTTONPROCCESSINGACTIVE;  
   ButtonTimerCnt=0;
   sTimerSyn16BitParams sTimer5Params;
   sTimer5Params.ctrl = (BM_T5CS1|BM_T5CS2|BM_T5CTC);  // 0x110 CLOCK/256, Clear on match 0x1000 ---> 0x1001 = 9;       
   sTimer5Params.compL = 0x48U;                        // T5CompL //MRC 1.4 MHz / 256 = 5.5 kHz = 181 uS 
   sTimer5Params.compH = 0x00U;                        // T5CompL //13 mS desired time / 181 uS = 72 = 0x48
   sTimer5Params.countL = 0x00U;                       // T5CountL
   sTimer5Params.countH = 0x00U;                       // T5CountH
   sTimer5Params.irqMask = (BM_T5CIM);                 // T5IrqMask
   sTimer5Params.ovfIsr = (timerIRQHandler)0x0000;     // g_sTimer5.ovfIsr
   sTimer5Params.compIsr = (timerIRQHandler)0x0000;    // g_sTimer5.compIsr
  
   if( !(g_sTimer5.bStatus & TMR5LOCK) )
   {  
   if (ATA_timer5Open_C(&sTimer5Params) == FAIL){
   ATA_systemErrorLoop_flash_C();}
   }
}
/*------------------------------------------------------------------------------*/
void ATA_RKEtimerProcess()
{
  uint8_t ButtonState;  
  _WDR; 
  gTimer5Status &= ~(BM_TIMER5COMPARETRUE);
  if (ButtonTimerCnt==0)
  {
  gFlashApplState.Buttons &= ~(BM_BUTTONFILTERON);//set filter off
  gFlashApplState.Buttons |= BM_BUTTONPROCCESSINGACTIVE;//set active true
  gFlashApplState.Buttons &= ~(BM_BUTTONDATAVALID);
  }  
  if ((PORTD & 0x04)==0x04) PORTD &= ~(1<<PORTD2);
  else PORTD |= (1<<PORTD2);
  ButtonTimerCnt++;
  ButtonState = ~(PIND | SW_BM);
  ButtonState = ButtonState>>3;
 if (   ((gFlashApplState.Buttons & BM_BUTTONDATAVALID)==BM_BUTTONDATAVALID)     ||  (ButtonTimerCnt>75))
  { 
    ATA_timer5Close_C(); 
    T5IMR = 0x00;
    PCIFR =0x03;
    if (  (gFlashApplState.Buttons & BM_NEWCMNDVALID)==0)//False trigger re-enable INTs
    { 
    Intr_Enable(SW1_INTR);    //Disable SW1,2,3 interrupts 
    Intr_Enable(SW2_INTR);
    Intr_Enable(SW3_INTR);
    }
    PORTD &= ~(1<<PORTD2);     
    ButtonTimerCnt=0;
    gFlashApplState.Buttons &= ~(BM_BUTTONPROCCESSINGACTIVE);//set active false
     gTimer5Status &= ~(BM_TIMER5COMPARETRUE);
  }
  else
  {
   uint8_t cmnd =  ATA_Flash_RKEbuttonfilter(ButtonState, ButtonTimerCnt); 
  }
}
