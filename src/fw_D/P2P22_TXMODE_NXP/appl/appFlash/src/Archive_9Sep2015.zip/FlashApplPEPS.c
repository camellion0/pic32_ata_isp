/* *C**************************************************************************
  Use of this software is subject to Atmel's Software License Agreement.
-------------------------------------------------------------------------------
  $URL: http://svnservulm.corp.atmel.com/svn/CDB/Apps/SW_Lib/Car_Access/CARS_GEN2/ATAB5702A/Branches/GR_inwork/appl/appFlash/src/FlashApplPEPS.c $
  $LastChangedRevision: 335779 $
  $LastChangedDate: 2015-09-04 13:13:49 -0600 (Fri, 04 Sep 2015) $
  $LastChangedBy: grueter $
-------------------------------------------------------------------------------
  Project:      ATA5700
  Target MCU:   ATA5700
  Compiler:     IAR C/C++ Compiler for AVR 5.51.0
-------------------------------------------------------------------------------

*******************************************************************************
* Copyright 2011, Atmel Automotive GmbH                                       *
*                                                                             *
* This software is owned by the Atmel Automotive GmbH                         *
* and is protected by and subject to worldwide patent protection.             *
* Atmel hereby grants to licensee a personal,                                 *
* non-exclusive, non-transferable license to copy, use, modify, create        *
* derivative works of, and compile the Atmel Source Code and derivative       *
* works for the sole purpose of creating custom software in support of        *
* licensee product to be used only in conjunction with a Atmel integrated     *
* circuit as specified in the applicable agreement. Any reproduction,         *
* modification, translation, compilation, or representation of this           *
* software except as specified above is prohibited without the express        *
* written permission of Atmel.                                                *
*                                                                             *
* Disclaimer: ATMEL MAKES NO WARRANTY OF ANY KIND,EXPRESS OR IMPLIED,         *
* WITH REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED    *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.         *
* Atmel reserves the right to make changes without further notice to the      *
* materials described herein. Atmel does not assume any liability arising     *
* out of the application or use of any product or circuit described herein.   *
* Atmel does not authorize its products for use as critical components in     *
* life-support systems where a malfunction or failure may reasonably be       *
* expected to result in significant injury to the user. The inclusion of      *
* Atmel products in a life-support systems application implies that the       *
* manufacturer assumes all risk of such use and in doing so indemnifies       *
* Atmel against all charges.                                                  *
*                                                                             *
* Use may be limited by and subject to the applicable Atmel software          *
* license agreement.                                                          *
******************************************************************************/

/** \file FlashApplPEPS.c
    this file contains an ATA5700 Flash application software
*/

/*===========================================================================*/
/*  INCLUDES                                                                 */
/*===========================================================================*/
#include "../../../firmware/init/src/init.h"
#include "../../../firmware/rftx/src/rftx.h"
#include "../../../firmware/lfrx/src/lfrx.h"
#include "../../../firmware/spi/src/ata5700_command_set_flash.h"

#include "../../../firmware/init/src/init_flash.h"
#include "../../../firmware/system/src/system_flash.h"

#include "../../../firmware/timer1/src/timer1.h"
#include "../../../firmware/globals/src/globals.h"

#include "../../../firmware/lfrx/src/lfrx_flash.h"
#include "../../../firmware/tp/src/tp_flash.h"

#include "../../../firmware/extif/src/extif_flash.h"

#include "../../../firmware/lfrssi/src/lfrssi.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"

#include "../../../firmware/calib/src/calib.h"
#include "../../../firmware/eep/src/eep.h"

#include "../src/FlashApplPEPS.h"
#include "../src/FlashApplLF.h" 
#include "../src/micro.h"

#include "../src/FlashApplVars.h"
#include "FlashApplMSG.h"
#include <stdbool.h>//OK

/*===========================================================================*/
/*  DEFINES                                                                  */
/*===========================================================================*/

#define MSG_RX_DATA (msg_rx_buffer.aub_data)
/*===========================================================================*/
/*  Modul Globals                                                             */
/*===========================================================================*/
uint8_t gLfMessageReceived; 
uint8_t gLfRxData[CFG_LF_BUFFER_SIZE];           // max LF buffer size = 32 bytes
uint8_t gLfNmbrRxByts;
uint16_t gExtLfRssi[3];
uint16_t gIntLfRssi[3];
uint16_t gLfRssiRes[3]; 
uint16_t wLfRssiref[3];
uint16_t wLfRssiNorm[3];
uint16_t wBref;
RFMSG_FRAME_TS msg_rx_buffer;
RFMSG_FRAME_TS msg_tx_buffer;



// command ID received
static uint8_t rub_cid;

// information on source message (channel LF/RF and wake-up id)
static uint8_t rub_wuip;

// Fob Index
static uint8_t rub_fob_idx;

// Fob ID
static uint8_t rul_fob_id;

// RF channel to use
uint8_t rub_rf_chan;

uint8_t gBattStatus; 
uint8_t gNTE_DIAG_MODE;

VOIDFUNC ATA_lfRxEnableWakeup_flash_C(uint8_t bLfBdrate,uint8_t bSense);
VOIDFUNC ATA_CheckLfData_flash_C(void);
VOIDFUNC Init_LfRssi_flash_C(void);
VOIDFUNC ATA_PerformLfRSSI_flash_C(uint8_t bmode, uint8_t bsign);
extern VOIDFUNC ATA_StartRssi_flash_C(void);
VOIDFUNC ATA_lFRssiGetResult_flash_C(uint8_t bmode, uint8_t bsign);
static VOIDFUNC ATA_GetIntRssiValues(void);
VOIDFUNC app_peps_handler(uint8_t lub_channel);
static VOIDFUNC _app_peps_task(void);

bool _peps_cmd_validity(void);

//Command with LF CW ?

uint8_t cabb_cmd_with_cw[16] =
{
  FALSE,
  FALSE, //PEPS_CID_RD_PARAM  1
  FALSE, //PEPS_CID_WR_PARAM  2
  FALSE,
  TRUE,  //PEPS_CID_2WAY     4
  TRUE,  //PEPS_CID_UNI_AUTH 5
  TRUE,  //PEPS_CID_BI_AUTH  6
  TRUE,  //PEPS_CID_UNI_AUTH_SING 7
  TRUE,  //PEPS_CID_BI_AUTH_SING  8
  FALSE,
  TRUE,  //PEPS_CID_LF_TST   10
  TRUE, //PEPS_CID_SET_REF  11
  FALSE,
  FALSE,
  FALSE, //PEPS_CID_SWID 14
  FALSE  //PEPS_CID_MODE 15
};



/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/


/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/

//-----------------------------------------------------------------------------
/** \brief <b>ATA_lfRxEnableWakeup_flash_C</b>
    Shall configure the 3D LF receiver into LF listen mode and activate
      the ID0 wake-up interrupt

    \param[in]  bLfBdrate       selects the LF baud rate
                bSense          selects the LF RX sensitivity
                pLf_Id          pointer to the LF wake-up ID
                bLf_IdLength    number of LF ID bits

    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
void ATA_lfRxEnableWakeup_flash_C(uint8_t bLfBdrate,uint8_t bSense)
{
  uint8_t laub_data[4];
  
  LDFCKSW |= (1<<LDFSCSW); 
  while ((LDFCKSW & (1<<LDFSCKS)) ==0);            // wait until clock source is switched
 

  LFQC1 = LFRX_R_Trim90k;
  LFQC2 = LFRX_R_Trim90k;
  LFQC3 = LFRX_R_Trim117k;
  LFCR0 = 0x80 | bLfBdrate | BM_LFCE1 | BM_LFCE2 | BM_LFCE3;    // activate all channels and set baudrate
  LFCR1 = BM_LFRE | BM_LFPEEN;                              // enable RX, ID and Data Mode
  LFCR2 = bSense;                                        // select sensitivity
  //LFCR3 = ;                                            // at first without trimming function
  LDFFL =0x80;
  
  #ifdef CFG_LF_WUP0_IN_EEPROM
  // Wake-up ID stored in EEprom as a buffer (MSB first)
  ATA_eepReadBytes_C(laub_data, CFG_LF_WUP0_Adr, 0x04 );
  PHID00 = laub_data[(CFG_LF_WUP0_LENGTH/8-1)%4];
  PHID01 = laub_data[(CFG_LF_WUP0_LENGTH/8-2)%4];
  PHID02 = laub_data[(CFG_LF_WUP0_LENGTH/8-3)%4];
  PHID03 = laub_data[(CFG_LF_WUP0_LENGTH/8)%4];
#else
  // Wake-up ID stored in RAM or Flash
  PHID00 = (CFG_LF_WUP0) & 0xFF;
  PHID01 = (CFG_LF_WUP0>> 8) & 0xFF;
  PHID02 = (CFG_LF_WUP0>>16) & 0xFF;
  PHID03 = (CFG_LF_WUP0>>24) & 0xFF;
#endif

  //Low Frequency IDentifier 1 data register (LFID1)
#ifdef CFG_LF_WUP1_IN_EEPROM
  // Wake-up ID stored in EEprom as a buffer (MSB first)
  ATA_eepReadBytes_C(laub_data, CFG_LF_WUP1_Adr);
  PHID10 = laub_data[(CFG_LF_WUP1_LENGTH/8-1)%4];
  PHID11 = laub_data[(CFG_LF_WUP1_LENGTH/8-2)%4];
  PHID12 = laub_data[(CFG_LF_WUP1_LENGTH/8-3)%4];
  PHID13 = laub_data[(CFG_LF_WUP1_LENGTH/8)%4];
#else
  // Wake-up ID stored in RAM or Flash
  PHID10 = (CFG_LF_WUP1) & 0xFF;
  PHID11 = (CFG_LF_WUP1>> 8) & 0xFF;
  PHID12 = (CFG_LF_WUP1>>16) & 0xFF;
  PHID13 = (CFG_LF_WUP1>>24) & 0xFF;
#endif
  
  
  // Settings for the protocol handler
 
  PHID0L = CFG_LF_WUP0_LENGTH;
  PHID1L = CFG_LF_WUP1_LENGTH;
  PHIDFR = LF_IDFRAMELENGTH;
  
  PHTBLR = 0xFF;                // Protocol Handler Telegram bit length
//  PHDFR = 48;
  
  LFSYSY0 = 0x09;
  LFSYLE = 0x04;
  
//  PHIMR |= (1<<4);       // Set PHID0IM=1 (ID0 IRQ mask)
  
  
  //Enable PB3/LFES as a debug port
  //DBGSW = 10;                       // Enable to drive debug test 10
  
  //LTEMR |= (1<<EOFEM);                // End of telegram triggers timer 
  //LDFIM |= (1<<LDFFLIM);                // fill level int.
  LFIMR |= (1<<LFEOIM);                 // enable EOF int for LF 
  
  gLfMessageReceived = 0x00; 
}


//-----------------------------------------------------------------------------
/** \brief <b>Init_LfRssi_flash_C</b>
    Prepare LF RSSI block for measurements
    

    \param[in]  none


    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
VOIDFUNC Init_LfRssi_flash_C(void)
{
  /* Temp. initialization of LF RSSI component data for use during System
  Verification */
  g_sLfRssi.bFlags = 0;
  g_sLfRssi.bStatus = 0;
  
  ATA_lfRssiInit_C();
  
  ATA_lfRssiMeasConfig_flash_C(PARALLEL_LFRSSI_MEASUREMENT);
  
}

//-----------------------------------------------------------------------------
/** \brief <b>ATA_PerformLfRSSI_flash_C</b>
    Contains the complete flow for performing an LF RSSI measurement
    

    \param[in]  bMode       Contains internal or external LF RSSI measurement request


    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
VOIDFUNC ATA_PerformLfRSSI_flash_C(uint8_t bmode, uint8_t bsign)
{
  ATA_StartRssi_flash_C();
  
  ATA_lfRssiMeasStart_C( &g_sLfRssiRegConfig_flash, bmode, bsign );
  do 
  {
    
  }
  while ((g_sLfRssi.bStatus & LFRSSI_STATUS_BM_MEAS_DATA_AVAILABLE_FLAG)==0); 
  
  ATA_lFRssiGetResult_flash_C(bmode, bsign);             

}

//-----------------------------------------------------------------------------
/** \brief <b>ATA_CheckLfData_flash_C</b>
    Reads out the received LF telegram from the internal LF data buffer
    

    \param[in]  none


    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/
VOIDFUNC ATA_CheckLfData_flash_C(void)
{
  uint8_t index;
  
  LDFCKSW |= (1<<LDFSCSW); 
  while ((LDFCKSW & (1<<LDFSCKS)) ==0);            // wait until clock source is switched
  gLfNmbrRxByts = LDFFL; 
  if (gLfNmbrRxByts !=0)
  {
    for (index=0; index < gLfNmbrRxByts; index++)
    {
      gLfRxData[index] = LDFD;
    }
  }
  LDFCKSW &= ~(1<<LDFSCSW);
  

}


/**
 * \brief PEPS Task on frame reception
 *        Start LF RSSI acquisiotns if needed
 *        Check WUID is coming from RF link
 *        Call PEPS handler
 *
 * \return none
 */
void app_peps_handler(uint8_t lub_channel)
{
//  uint8_t laub_data[4];
  uint8_t bMargin; 
   
  // accept only frames with more than 5 bytes (WUID + CID + CKS)
  if (gLfNmbrRxByts >= 5)               //MiHa muss noch pr�fen ob dies richtig ist
  {
    // get CID
    rub_cid = ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->cid;
    rub_cid = (gLfRxData[0]& BM_CID);           // contains cmd and key
    rub_wuip = lub_channel;
    
    if (rub_wuip&RX_CHAN_LF_MSK)
    { 
      // message received by LF
      rub_wuip |= (rub_wuip<<3);    // set WUID source
      // RSSI acquisitions ?
      if (cabb_cmd_with_cw[rub_cid])
      {
        // acquire internal RSSI (CW OFF)
        Init_LfRssi_flash_C();
        ATA_PerformLfRSSI_flash_C(LFRSSI_INT, NO_SIGNDET);
        // wait before external field measurement
        //TIMEB_WAIT_US((16-CFG_LF_RSSI_ACQ)*100);   //MiHa delay must be added to get to the start of CW
        // acquire external RSSI (CW ON)
        ATA_PerformLfRSSI_flash_C(LFRSSI_EXT, NO_SIGNDET);
        ATA_eepReadBytes_C(&bMargin, MARGIN_EEADR, 0x01);
        ATA_eepReadBytes_C((uint8_t*)&wLfRssiref[0], LFRSSIREF_EEADR, 0x02);
        ATA_eepReadBytes_C((uint8_t*)&wLfRssiNorm[0], LFRSSINORM_EEADR, 0x02);
        ATA_lfRssiCalcChanCalibVal_C(bMargin, &wLfRssiref[0],&wLfRssiNorm[0]);
        ATA_lfRssiCalcCorr_C();
      }
      // force emission on channel 1 when command is received by LF
      rub_rf_chan = 0; //Toby - was 1
    }
    else
    {
//      // message received by RF
//      // Note: ATA5831 returns 1 additionnal byte due to additionnal bit in EOF
//      msg_rx_buffer.ub_size -= 1;
//      
//      // check if wake-up ID match WUID0
//#ifdef CFG_LF_WUP0_IN_EEPROM    
//      EEPDATA_READ(laub_data, CFG_LF_WUP0);
//#else
//      laub_data[3] = (CFG_LF_WUP0>>((CFG_LF_WUP0_LENGTH-32)&0x1F)) & 0xFF;
//      laub_data[2] = (CFG_LF_WUP0>>((CFG_LF_WUP0_LENGTH-24)&0x1F)) & 0xFF;
//      laub_data[1] = (CFG_LF_WUP0>>((CFG_LF_WUP0_LENGTH-16)&0x1F)) & 0xFF;
//      laub_data[0] = (CFG_LF_WUP0>>((CFG_LF_WUP0_LENGTH-8)&0x1F)) & 0xFF;
//#endif
//      if (memory_compare(((RX_MSG_PEPS_TS*)MSG_RX_DATA)->vid,
//                          laub_data, CFG_PEPS_VID_LENGTH))
//      {
//        rub_wuip = RX_WUID0;
//      }
//      
//      // check if wake-up ID match WUID1
//#ifdef CFG_LF_WUP1_IN_EEPROM    
//      EEPDATA_READ(laub_data, CFG_LF_WUP1);
//#else
//      laub_data[3] = (CFG_LF_WUP1>>((CFG_LF_WUP0_LENGTH-32)&0x1F)) & 0xFF;
//      laub_data[2] = (CFG_LF_WUP1>>((CFG_LF_WUP0_LENGTH-24)&0x1F)) & 0xFF;
//      laub_data[1] = (CFG_LF_WUP1>>((CFG_LF_WUP0_LENGTH-16)&0x1F)) & 0xFF;
//      laub_data[0] = (CFG_LF_WUP1>>((CFG_LF_WUP0_LENGTH-8)&0x1F)) & 0xFF;
//#endif
//      if (memory_compare(((RX_MSG_PEPS_TS*)MSG_RX_DATA)->vid,
//                         laub_data, CFG_PEPS_VID_LENGTH))
//      {
//        rub_wuip = RX_WUID1;
//      }
    }
    // LF_ENABLE(FALSE);   //hier sollte jetzt die Berechnung gemacht werden und dann kann der LF ausgeschalten werden
    
//    if (rub_wuip&RX_WUID_MSK)
//    {
      _app_peps_task();         
//    }
  }
}

//-----------------------------------------------------------------------------
/** \brief <b>ATA_lFRssiGetResult_flash_C<void>
    Read out the result from the last LF RSSI measurements and store them 
      to the global variables

    \param[in] none

    \return none


    \Traceability None

    \image none
    \n
*/
/*---------------------------------------------------------------------------*/

void ATA_lFRssiGetResult_flash_C(uint8_t bmode, uint8_t bsign)
{

  RSMS1R &= ~(1<<RSSSV);        // for output the everage value
  if (bmode == 0)
  {
    gExtLfRssi[0] = (RSRES1H<<8) ;
    gExtLfRssi[0] |= RSRES1L;
    gExtLfRssi[1] = (RSRES2H<<8) ;
    gExtLfRssi[1] |= RSRES2L;
    gExtLfRssi[2] = (RSRES3H<<8) ;
    gExtLfRssi[2] |= RSRES3L;
    
  }
  else 
  {
    gIntLfRssi[0] = (RSRES1H<<8) ;
    gIntLfRssi[0] |= RSRES1L;
    gIntLfRssi[1] = (RSRES2H<<8) ;
    gIntLfRssi[1] |= RSRES2L;
    gIntLfRssi[2] = (RSRES3H<<8) ;
    gIntLfRssi[2] |= RSRES3L;
  }
}



/**
 * \brief PEPS common Task
 *        Analyse and execute frame receive
 *        Prepare RF message reply
 *        Send RF message reply
 *        Acquire battery status
 *        Light ON LED for 50ms
 *
 * \return none
 */
static void _app_peps_task(void)
{
  // execute command
  if (_peps_cmd_validity())
  
  {
    // light on LED
    bit_set(LED1);
    
//#ifdef CFG_APP_2WAYRF
//    // wake-up RF
//    rf_ata5831_setmode(E_STATE_IDLE, (RF_ATA5831_CONFIG_TU){0});
//#else // ONE WAY
//    // start XTO quartz now so that it is stabilized when we need to transmit
//    rf_ata5791_setmode(RF_MODE_IDLE);
//#endif

    // Build RF message
//    _peps_build_msg();          //MiHa is done by George

    //activate voltage monitor
    PRR0 &= ~BM_PRVM;  //remove power reduction on voltage monitor  
    VMSCR |= BM_VMF; // clear VMF flag
    VMCR = BM_VM_VBAT | BM_VM_2_1V; 

    // Send RF message
//    _peps_send_msg();         //MiHa is done by George

    // update battery flag
    gBattStatus = (VMSCR & (1<<VMF));

    // stop voltage monitor
    VMCR = BM_VM_DISABLE;
    PRR0 |= (1<<PRVM);

    // must be checked if delay must be added
    bit_clear(LED1);
  }
}



/**
 * \brief Verify LF frame command validity
 *        Check managed CID, Frame lenght, CRC if any, WUP ID used, Diag mode
 *        Command parameter (with cyphered challenge in case of bilateral authent)
 *
 * \return TRUE if command is valid, FALSE otherwise
 */
static bool _peps_cmd_validity(void)

{
 
  // init global variables
  ATA_eepReadBytes_C((uint8_t*)&rub_fob_idx, eub_fidx, 0x01);
  ATA_eepReadBytes_C((uint8_t*)&rul_fob_id, eul_key_id, 0x01);
  
  // check wake-up ID source
  switch (rub_cid)
  {
    case PEPS_CID_WR_PARAM:
    case PEPS_CID_RD_PARAM:
      if ((rub_wuip&RX_WUID_MSK) == RX_WUID1)
      {
        // wrong wake-up or wrong index
        return FALSE;
      }
//      else if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx != rub_fob_idx)
//      {
//        // wrong fob index
//        return FALSE;
//      }
      break;

    case PEPS_CID_2WAY:
      // allowed everytime
      break;

    case PEPS_CID_UNI_AUTH_SINGLE:
    case PEPS_CID_BI_AUTH_SINGLE:
//      if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx != rub_fob_idx)
//      {
//        // wrong fob index
//        return FALSE;
//      }
    case PEPS_CID_UNI_AUTH:
    case PEPS_CID_BI_AUTH:
      if ((rub_wuip&RX_WUID_MSK) == RX_WUID1)
      {
        // wrong wake-up
        return FALSE;
      }
      break;
      
    default:
      if ((rub_wuip&RX_WUID_MSK) == RX_WUID0)
      {
        // vehicle wake-up
//        if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->fidx != rub_fob_idx)
//        {
//          // wrong fob index
//          return FALSE;
//        }
      }
  }

  // check mode
  switch (rub_cid)
  {
    case PEPS_CID_RD_PARAM:
    case PEPS_CID_WR_PARAM:
      if (gNTE_DIAG_MODE == DIAG_OFF)
      {
        // forbiddden in DIAG OFF
        return FALSE;
      }
      break;

    case PEPS_CID_LF_PARAM:
      if (gNTE_DIAG_MODE != DIAG_OEM)
      {
        // only allowed in OEM mode
        return FALSE;
      }
      break;
      
    default:
      break;
  }

  // check CRC
  if ((rub_cid < PEPS_CID_UNI_AUTH) || (rub_cid > PEPS_CID_BI_AUTH_SINGLE))
  { /// only for non auth commands
 
 
    //**
    msg_rx_buffer.ub_size = 0x01;
    
    
    //if ((msg_rx_buffer.aub_data)[(msg_rx_buffer.ub_size)-1] !=   
      //  crc_compute(MSG_RX_DATA+CFG_PEPS_VID_LENGTH, 
      //             MSG_RX_CNT-CFG_PEPS_VID_LENGTH-1,
       //             CRC_INIT_00,
       //             CRC_POLY_CCIT))
    {
      return FALSE;
    }
  }

  // check command parameters
  switch (rub_cid)
  {
    case PEPS_CID_RD_PARAM:
    case PEPS_CID_WR_PARAM:
      
      //**
  //    if (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_rd_param.param_index >=32)
  //    {
        // wrong parameter index
  //      return FALSE;
 //     }
      break;

    case PEPS_CID_BI_AUTH:
    case PEPS_CID_BI_AUTH_SINGLE:
      // check cyphered challenge
 //     TIMEB_CLK_SPEED(CLK_SPEED_FULL);
      // load AES Key
 //     EEPDATA_READ(raub_aes_keyin_cyphout, eaub_aes_key_vehicle);
      // load challenge and cypher it
      
      //**
  //    aes_calc((uint8_t*)(((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_auth_bi.challenge),
   //            CFG_PEPS_CHALLENGE_LENGTH, TRUE, FALSE);
 
      
      //     TIMEB_CLK_SPEED(CLK_SPEED_NORM);
      // compare challenge cyphered with the on received
   //   if (!memory_compare(raub_aes_keyin_cyphout,
   //                       (((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_auth_bi.cyph_challenge),
   //                       CFG_PEPS_CHALLENGE_CYPH_LENGTH))
      {
        return FALSE;
      }
      break;

    case PEPS_CID_MODE:
      // check FOB ID
      
      //**
  //    if (rul_fob_id != ((RX_MSG_PEPS_TS*)MSG_RX_DATA)->data_mode.fid)
    //  {
        // wrong ID
   //     return FALSE;
   //   }
      break;
      
    default:
      break;
  }

  return TRUE;
}

