/* *C**************************************************************************
  Use of this software is subject to Atmel's Software License Agreement.
-------------------------------------------------------------------------------
  $URL: http://svnservulm.corp.atmel.com/svn/CDB/Apps/SW_Lib/Car_Access/CARS_GEN2/ATAB5702A/Branches/GR_inwork/appl/appFlash/src/FlashApplRF.c $
  $LastChangedRevision: 328482 $
  $LastChangedDate: 2015-07-22 13:17:23 -0600 (Wed, 22 Jul 2015) $
  $LastChangedBy: grueter $
-------------------------------------------------------------------------------
  Project:      ATA5700
  Target MCU:   ATA5700
  Compiler:     IAR C/C++ Compiler for AVR 5.51.0
-------------------------------------------------------------------------------

*******************************************************************************
* Copyright 2011, Atmel Automotive GmbH                                       *
*                                                                             *
* This software is owned by the Atmel Automotive GmbH                         *
* and is protected by and subject to worldwide patent protection.             *
* Atmel hereby grants to licensee a personal,                                 *
* non-exclusive, non-transferable license to copy, use, modify, create        *
* derivative works of, and compile the Atmel Source Code and derivative       *
* works for the sole purpose of creating custom software in support of        *
* licensee product to be used only in conjunction with a Atmel integrated     *
* circuit as specified in the applicable agreement. Any reproduction,         *
* modification, translation, compilation, or representation of this           *
* software except as specified above is prohibited without the express        *
* written permission of Atmel.                                                *
*                                                                             *
* Disclaimer: ATMEL MAKES NO WARRANTY OF ANY KIND,EXPRESS OR IMPLIED,         *
* WITH REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED    *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.         *
* Atmel reserves the right to make changes without further notice to the      *
* materials described herein. Atmel does not assume any liability arising     *
* out of the application or use of any product or circuit described herein.   *
* Atmel does not authorize its products for use as critical components in     *
* life-support systems where a malfunction or failure may reasonably be       *
* expected to result in significant injury to the user. The inclusion of      *
* Atmel products in a life-support systems application implies that the       *
* manufacturer assumes all risk of such use and in doing so indemnifies       *
* Atmel against all charges.                                                  *
*                                                                             *
* Use may be limited by and subject to the applicable Atmel software          *
* license agreement.                                                          *
******************************************************************************/

/** \file FlashApplRF.c
    this file contains an ATA5700 Flash application software
*/

/*===========================================================================*/
/*  INCLUDES                                                                 */
/*===========================================================================*/
#include "../../../firmware/init/src/init.h"
#include "../../../firmware/rftx/src/rftx.h"
#include "../../../firmware/lfrx/src/lfrx.h"
#include "../../../firmware/spi/src/ata5700_command_set.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"
#include "../../../firmware/init/src/init_flash.h"
#include "../../../firmware/system/src/system_flash.h"

#include "../../../firmware/timer1/src/timer1.h"
#include "../../../firmware/globals/src/globals.h"

#include "../../../firmware/lfrx/src/lfrx_flash.h"
#include "../../../firmware/tp/src/tp_flash.h"

#include "../../../firmware/extif/src/extif_flash.h"

#include "../../../firmware/lfrssi/src/lfrssi.h"
#include "../../../firmware/lfrssi/src/lfrssi_flash.h"

#include "../../../firmware/calib/src/calib.h"
#include "../../../firmware/aes/src/aes.h"

//--------

#include "../src/FlashApplPEPS.h"
#include "../src/FlashApplLF.h" 
#include "../src/micro.h"

#include "../src/FlashApplVars.h"


#include "rfrcc_flash.h"
#include "FlashApplVars.h"
#include "FlashApplMsg.h"

/*===========================================================================*/
/*  DEFINES                                                                  */
/*===========================================================================*/
#define TX_PAYLOADDATALENGTH    32
/*===========================================================================*/
/*  Modul Globals                                                             */
/*===========================================================================*/
uint8_t PAYLOADDATA  [ TX_PAYLOADDATALENGTH ]; //32
extern sFlashApplVars gFlashApplVars;

/*===========================================================================*/
/*  IMPLEMENTATION                                                           */
/*===========================================================================*/
//static VOIDFUNC ATA_rfTx_lFRssi_flash_C(void);
void ATA_rfTx_PEPSmsg_flash_C(void);
void ATA_rfTx_PEPSframe_flash_C(void);
/*----------------------------------------------------------------------------- */
/**\brief  TODO - code here

 */
/*----------------------------------------------------------------------------- */
void ATA_rfTx_lFRssi_flash_C(void)
{
  uint8_t index;  
  uint8_t checksum;
          PORTD |= (1<<4);  // Set PD4 high (LED2)
          for (index = 0; index < 14; index++)
          {
            PAYLOADDATA[index] = 0xFF;
          }
          PAYLOADDATA[14] = 0xFEU; 
          PAYLOADDATA[15] = 0x39U; 
        /*
          PAYLOADDATA[16] = g_sLfRssi.wRawLfRssi[0]&0xffU;
          PAYLOADDATA[17] = (g_sLfRssi.wRawLfRssi[0]>>8)&0xffU;
          
          PAYLOADDATA[18] = g_sLfRssi.wRawLfRssi[1]&0xffU;
          PAYLOADDATA[19] = (g_sLfRssi.wRawLfRssi[1]>>8)&0xffU;
          
          PAYLOADDATA[20] = g_sLfRssi.wRawLfRssi[2]&0xffU;
          PAYLOADDATA[21] = (g_sLfRssi.wRawLfRssi[2]>>8)&0xffU;
         */     
        
         
          
          for (index = 0; index < 23; index++)
          {
            checksum += PAYLOADDATA[index];
          }
          PAYLOADDATA[23] = ~checksum+1; 
         ATA_rfTxInit_C();
          ATA_rfTxFillDFifo_C(0x19U, PAYLOADDATA);
          // start rfTx with eeprom service g_sEepRfTxServiceConfig1
  
         //  uint8_t *pService = ATA_5700convertTrxConf2rfTxService_flash_C();
         //  ATA_rfTxStartTx_C(0x48, (uint8_t *) pService);          
         //   ATA_rfTxStartTx_C(0x48, (uint8_t *) (uint8_t *) &g_sEepRfTxServiceConfig1);
          ATA_rfTxStartTx_C(0x48, (uint8_t *) 0x06D0);
          
          
          do {
            ATA_rfTxProcessing_C();
             }while (g_sRfTx.bStatus & BM_RFTXCONFIG_BSTATUS_ACTIVE);
          for (uint8_t cnt=0;cnt<255;cnt++);
          ATA_rfTxStop_C();
          PORTD &= 0xef;     // Set PD4 low         
}

void ATA_rfTx_PEPSmsg_flash_C(void)
{
  gFlashApplVars.FOBindex=0;
  //Send message in common and FOB index time slots
  ATA_rfTx_PEPSframe_flash_C();
}

void ATA_rfTx_PEPSframe_flash_C(void)
{
  msg_tx_buffer.ub_size = 0x10;
  uint8_t index;  
  uint8_t checksum;
  for (index = 0; index < msg_tx_buffer.ub_size; index++)
      {
       PAYLOADDATA[index] = msg_tx_buffer.aub_data[index];
      }
   ATA_rfTxInit_C();
   ATA_rfTxFillDFifo_C(0x19U, PAYLOADDATA);
   ATA_rfTxStartTx_C(0x48, (uint8_t *) 0x06D0);
   do {
        ATA_rfTxProcessing_C();
       }while (g_sRfTx.bStatus & BM_RFTXCONFIG_BSTATUS_ACTIVE);
   for (uint8_t cnt=0;cnt<255;cnt++);
   ATA_rfTxStop_C();
}